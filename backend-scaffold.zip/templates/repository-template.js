import { ObjectId, Decimal128 } from 'mongodb';
import { getDatabase, getClient, serializeDoc, tenantFilter } from '../../config/database.js';
import { logger } from '../../utils/logger.js';

/**
 * Find One Product by ID
 */
export async function findOne(id, userContext) {
  try {
    const db = getDatabase();
    const product = await db.collection('products').findOne({
      _id: new ObjectId(id),
      ...tenantFilter(userContext),
    });

    return product ? { id: product._id.toString(), ...serializeDoc(product) } : null;
  } catch (error) {
    logger.error({ error }, 'Error finding product');
    throw error;
  }
}

/**
 * Find Product by Code
 */
export async function findByCode(code, userContext) {
  try {
    const db = getDatabase();
    const product = await db.collection('products').findOne({
      product_code: code,
      ...tenantFilter(userContext),
    });

    return product ? { id: product._id.toString(), ...serializeDoc(product) } : null;
  } catch (error) {
    logger.error({ error }, 'Error finding product by code');
    throw error;
  }
}

/**
 * Find Many Products (with pagination)
 */
export async function findMany(page, limit, userContext) {
  try {
    const db = getDatabase();
    const skip = (page - 1) * limit;

    const filter = tenantFilter(userContext);

    const products = await db
      .collection('products')
      .find(filter)
      .sort({ cr_date: -1 })
      .skip(skip)
      .limit(limit)
      .toArray();

    const total = await db.collection('products').countDocuments(filter);

    const serialized = products.map(p => ({
      id: p._id.toString(),
      ...serializeDoc(p),
    }));

    return {
      data: serialized,
      total,
    };
  } catch (error) {
    logger.error({ error }, 'Error finding products');
    throw error;
  }
}

/**
 * Create Product (with transaction + audit log)
 */
export async function create(data, userContext) {
  const client = getClient();
  const session = client.startSession();

  try {
    let result;

    await session.withTransaction(async () => {
      const db = getDatabase();
      const now = new Date();

      // Build create payload
      const createPayload = {
        ...data,
        // Convert price to Decimal128
        price: Decimal128.fromString(String(data.price)),
        // Tenant fields
        ou_id: new ObjectId(userContext.ou_id),
        branch_id: new ObjectId(userContext.branch_id),
        is_deleted: false,
        // Create audit fields
        cr_by: userContext.username,
        cr_date: now,
        cr_prog: '/api/v1/products',
        // Update audit fields (set together)
        upd_by: userContext.username,
        upd_date: now,
        upd_prog: '/api/v1/products',
        // Soft delete fields
        deleted_by: null,
        deleted_date: null,
        deleted_prog: null,
      };

      // Insert main document
      const insertResult = await db
        .collection('products')
        .insertOne(createPayload, { session });

      // Insert audit log
      await db
        .collection('product_logs')
        .insertOne(
          {
            action: 'INSERT',
            changed_fields: null,
            snapshot_data: { old: null, new: createPayload },
            ref_id: insertResult.insertedId,
            ou_id: createPayload.ou_id,
            branch_id: createPayload.branch_id,
            cr_by: userContext.username,
            cr_date: now,
            cr_prog: '/api/v1/products',
          },
          { session }
        );

      result = {
        id: insertResult.insertedId.toString(),
        ...serializeDoc(createPayload),
      };
    });

    return result;
  } catch (error) {
    logger.error({ error }, 'Error creating product');
    throw error;
  } finally {
    await session.endSession();
  }
}

/**
 * Update Product (with optimistic locking + transaction)
 */
export async function update(id, data, userContext, currentUpdDate) {
  const client = getClient();
  const session = client.startSession();

  try {
    let result;

    await session.withTransaction(async () => {
      const db = getDatabase();
      const now = new Date();

      // Optimistic locking check
      const filter = {
        _id: new ObjectId(id),
        ...tenantFilter(userContext),
        upd_date: currentUpdDate,
      };

      const oldDoc = await db.collection('products').findOne(filter, { session });

      if (!oldDoc) {
        throw new Error('Data not found or already modified');
      }

      // Build update payload
      const updatePayload = {
        ...data,
        // Convert price if present
        ...(data.price && { price: Decimal128.fromString(String(data.price)) }),
        // Update audit fields
        upd_by: userContext.username,
        upd_date: now,
        upd_prog: '/api/v1/products',
      };

      // Update main document
      await db
        .collection('products')
        .updateOne(filter, { $set: updatePayload }, { session });

      // Calculate changed fields
      const changedFields = {};
      Object.keys(updatePayload).forEach(key => {
        if (key !== 'upd_by' && key !== 'upd_date' && key !== 'upd_prog') {
          if (JSON.stringify(oldDoc[key]) !== JSON.stringify(updatePayload[key])) {
            changedFields[key] = {
              old: oldDoc[key],
              new: updatePayload[key],
            };
          }
        }
      });

      // Insert audit log
      await db
        .collection('product_logs')
        .insertOne(
          {
            action: 'UPDATE',
            changed_fields: Object.keys(changedFields).length > 0 ? changedFields : null,
            snapshot_data: { old: oldDoc, new: { ...oldDoc, ...updatePayload } },
            ref_id: oldDoc._id,
            ou_id: oldDoc.ou_id,
            branch_id: oldDoc.branch_id,
            cr_by: userContext.username,
            cr_date: now,
            cr_prog: '/api/v1/products',
          },
          { session }
        );

      result = {
        id: oldDoc._id.toString(),
        ...serializeDoc({ ...oldDoc, ...updatePayload }),
      };
    });

    return result;
  } catch (error) {
    logger.error({ error }, 'Error updating product');
    throw error;
  } finally {
    await session.endSession();
  }
}

/**
 * Delete Product (soft delete with transaction)
 */
export async function delete_(id, userContext) {
  const client = getClient();
  const session = client.startSession();

  try {
    await session.withTransaction(async () => {
      const db = getDatabase();
      const now = new Date();

      const filter = {
        _id: new ObjectId(id),
        ...tenantFilter(userContext),
      };

      const oldDoc = await db.collection('products').findOne(filter, { session });

      if (!oldDoc) {
        throw new Error('Product not found');
      }

      // Soft delete payload
      const deletePayload = {
        is_deleted: true,
        deleted_by: userContext.username,
        deleted_date: now,
        deleted_prog: '/api/v1/products',
        upd_by: userContext.username,
        upd_date: now,
        upd_prog: '/api/v1/products',
      };

      // Update document
      await db
        .collection('products')
        .updateOne(filter, { $set: deletePayload }, { session });

      // Insert audit log
      await db
        .collection('product_logs')
        .insertOne(
          {
            action: 'DELETE',
            changed_fields: null,
            snapshot_data: { old: oldDoc, new: null },
            ref_id: oldDoc._id,
            ou_id: oldDoc.ou_id,
            branch_id: oldDoc.branch_id,
            cr_by: userContext.username,
            cr_date: now,
            cr_prog: '/api/v1/products',
          },
          { session }
        );
    });
  } catch (error) {
    logger.error({ error }, 'Error deleting product');
    throw error;
  } finally {
    await session.endSession();
  }
}

export default {
  findOne,
  findByCode,
  findMany,
  create,
  update,
  delete: delete_,
};
