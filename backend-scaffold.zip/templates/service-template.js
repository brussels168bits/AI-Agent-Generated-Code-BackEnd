import * as productRepository from './products.repository.js';
import { logger } from '../../utils/logger.js';

/**
 * List Products
 */
export async function listProducts(pagination, userContext) {
  try {
    const { page = 1, limit = 10 } = pagination;

    // Validate pagination
    const pageNum = Math.max(1, page);
    const limitNum = Math.min(Math.max(1, limit), 100); // Max 100

    const result = await productRepository.findMany(
      pageNum,
      limitNum,
      userContext
    );

    return {
      success: true,
      code: 'SUCCESS',
      message: null,
      data: result.data,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total: result.total,
        totalPages: Math.ceil(result.total / limitNum),
      },
    };
  } catch (error) {
    logger.error({ error }, 'Error listing products');
    throw error;
  }
}

/**
 * Get Product Detail
 */
export async function getProduct(id, userContext) {
  try {
    const product = await productRepository.findOne(id, userContext);

    if (!product) {
      return {
        success: false,
        code: 'DATA_NOT_FOUND',
        message: 'Product not found',
      };
    }

    return {
      success: true,
      code: 'SUCCESS',
      message: null,
      data: product,
    };
  } catch (error) {
    logger.error({ error }, 'Error getting product');
    throw error;
  }
}

/**
 * Create Product
 */
export async function createProduct(data, userContext) {
  try {
    // Business Logic Validation
    if (!data.product_name || data.product_name.trim() === '') {
      return {
        success: false,
        code: 'INVALID_PARAM',
        message: 'Product name is required',
      };
    }

    if (data.quantity < 0) {
      return {
        success: false,
        code: 'INVALID_PARAM',
        message: 'Quantity must be positive',
      };
    }

    // Check for duplicate code
    const existingProduct = await productRepository.findByCode(
      data.product_code,
      userContext
    );

    if (existingProduct) {
      return {
        success: false,
        code: 'CONFLICT',
        message: `Product code ${data.product_code} already exists`,
      };
    }

    // Create via repository
    const createdProduct = await productRepository.create(data, userContext);

    return {
      success: true,
      code: 'SUCCESS',
      message: null,
      data: createdProduct,
    };
  } catch (error) {
    logger.error({ error }, 'Error creating product');
    throw error;
  }
}

/**
 * Update Product
 */
export async function updateProduct(id, data, userContext) {
  try {
    // Get current version for optimistic locking
    const currentProduct = await productRepository.findOne(id, userContext);

    if (!currentProduct) {
      return {
        success: false,
        code: 'DATA_NOT_FOUND',
        message: 'Product not found',
      };
    }

    // Business Logic Validation
    if (data.quantity !== undefined && data.quantity < 0) {
      return {
        success: false,
        code: 'INVALID_PARAM',
        message: 'Quantity must be positive',
      };
    }

    // Update via repository
    try {
      const updatedProduct = await productRepository.update(
        id,
        data,
        userContext,
        currentProduct.updatedAt
      );

      return {
        success: true,
        code: 'SUCCESS',
        message: null,
        data: updatedProduct,
      };
    } catch (error) {
      if (error.message.includes('not found or already modified')) {
        return {
          success: false,
          code: 'CONFLICT',
          message: 'Data has been modified. Please refresh and try again.',
        };
      }
      throw error;
    }
  } catch (error) {
    logger.error({ error }, 'Error updating product');
    throw error;
  }
}

/**
 * Delete Product
 */
export async function deleteProduct(id, userContext) {
  try {
    const product = await productRepository.findOne(id, userContext);

    if (!product) {
      return {
        success: false,
        code: 'DATA_NOT_FOUND',
        message: 'Product not found',
      };
    }

    await productRepository.delete(id, userContext);

    return {
      success: true,
      code: 'SUCCESS',
      message: null,
      data: null,
    };
  } catch (error) {
    logger.error({ error }, 'Error deleting product');
    throw error;
  }
}

export default {
  listProducts,
  getProduct,
  createProduct,
  updateProduct,
  deleteProduct,
};
