import pino from 'pino';

/**
 * Pino logger setup
 * Never use console.log - use logger instead
 */
const logLevel = process.env.LOG_LEVEL || 'info';

export const logger = pino({
  level: logLevel,
  transport: {
    target: 'pino-pretty',
    options: {
      colorize: true,
      singleLine: false,
      translateTime: 'SYS:standard',
      ignore: 'pid,hostname',
    },
  },
});

/**
 * Logger methods
 * - logger.info()    ← Normal operations
 * - logger.error()   ← Exceptions / errors
 * - logger.debug()   ← Verbose debugging
 * - logger.warn()    ← Warnings
 */

export default logger;
