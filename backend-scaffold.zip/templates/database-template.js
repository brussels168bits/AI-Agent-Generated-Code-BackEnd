import { MongoClient, ObjectId, Decimal128 } from 'mongodb';
import { logger } from './logger.js';

let client;
let db;

/**
 * Initialize MongoDB connection
 */
export async function initializeDatabase() {
  try {
    const url = process.env.DATABASE_URL || 'mongodb://localhost:27017';
    const dbName = process.env.DATABASE_NAME || 'my-api';

    client = new MongoClient(url, {
      replicaSet: process.env.DATABASE_REPLICA_SET,
      retryWrites: true,
      maxPoolSize: 10,
      minPoolSize: 2,
    });

    await client.connect();
    db = client.db(dbName);

    logger.info('Connected to MongoDB');

    // Verify connection
    await db.admin().ping();
    logger.info('MongoDB connection verified');

    return db;
  } catch (error) {
    logger.error('Failed to connect to MongoDB:', error);
    throw error;
  }
}

/**
 * Get database instance
 */
export function getDatabase() {
  if (!db) {
    throw new Error('Database not initialized. Call initializeDatabase() first.');
  }
  return db;
}

/**
 * Get MongoDB client
 */
export function getClient() {
  if (!client) {
    throw new Error('Client not initialized. Call initializeDatabase() first.');
  }
  return client;
}

/**
 * Close database connection
 */
export async function closeDatabase() {
  try {
    if (client) {
      await client.close();
      logger.info('MongoDB connection closed');
    }
  } catch (error) {
    logger.error('Error closing MongoDB connection:', error);
    throw error;
  }
}

/**
 * Convert Decimal128 to String (for API responses)
 */
export function serializeDoc(doc) {
  if (!doc) return null;

  const serialized = { ...doc };

  Object.keys(serialized).forEach(key => {
    if (serialized[key] instanceof Decimal128) {
      serialized[key] = serialized[key].toString();
    }
  });

  return serialized;
}

/**
 * Create tenantFilter helper
 */
export function tenantFilter(userContext) {
  return {
    ou_id: new ObjectId(userContext.ou_id),
    branch_id: new ObjectId(userContext.branch_id),
    is_deleted: false,
  };
}

/**
 * Health check
 */
export async function healthCheck() {
  try {
    const db = getDatabase();
    const ping = await db.admin().ping();
    return { success: true, message: 'Database healthy' };
  } catch (error) {
    return { success: false, message: error.message };
  }
}

/**
 * Create indexes for a collection
 */
export async function createCollectionIndexes(collectionName, indexes) {
  try {
    const db = getDatabase();
    const collection = db.collection(collectionName);

    for (const indexSpec of indexes) {
      await collection.createIndex(indexSpec.key, {
        name: indexSpec.name,
        unique: indexSpec.unique || false,
      });
    }

    logger.info(`Created indexes for collection: ${collectionName}`);
  } catch (error) {
    logger.error(`Error creating indexes for ${collectionName}:`, error);
    throw error;
  }
}

export default {
  initializeDatabase,
  getDatabase,
  getClient,
  closeDatabase,
  serializeDoc,
  tenantFilter,
  healthCheck,
  createCollectionIndexes,
};
