import { v4 as uuidv4 } from 'uuid';
import jwt from 'jsonwebtoken';
import rateLimit from 'express-rate-limit';
import { logger } from './logger.js';
import { AppError } from './app-error.js';

/**
 * Request ID Middleware
 * Adds unique ID to every request for tracking
 */
export function requestIdMiddleware(req, res, next) {
  req.id = uuidv4();
  res.setHeader('X-Request-ID', req.id);
  next();
}

/**
 * Authentication Middleware
 * Extracts and verifies JWT from Authorization header
 */
export function authenticate(req, res, next) {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return next(new AppError(401, 'UNAUTHORIZED', 'Missing or invalid authorization header'));
    }

    const token = authHeader.substring(7);

    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = {
        username: decoded.username,
        ou_id: decoded.ou_id,
        branch_id: decoded.branch_id,
        roles: decoded.roles || [],
      };
      next();
    } catch (err) {
      if (err.name === 'TokenExpiredError') {
        return next(new AppError(401, 'TOKEN_EXPIRED', 'Your session has expired'));
      }
      return next(new AppError(401, 'UNAUTHORIZED', 'Invalid token'));
    }
  } catch (error) {
    next(error);
  }
}

/**
 * Validate Middleware
 * Validates request body against Joi schema
 */
export function validate(schema) {
  return (req, res, next) => {
    const { error, value } = schema.validate(req.body, {
      abortEarly: false,
      stripUnknown: true,
    });

    if (error) {
      const messages = error.details.map(d => d.message).join(', ');
      return next(new AppError(400, 'INVALID_PARAM', messages));
    }

    req.body = value;
    next();
  };
}

/**
 * Rate Limit Middleware - General
 */
export const generalLimiter = rateLimit({
  windowMs: 60 * 1000,            // 1 minute
  max: process.env.RATE_LIMIT_MAX_REQUESTS || 100,
  message: 'Too many requests, please try again later',
  skipSuccessfulRequests: false,
  skipFailedRequests: false,
});

/**
 * Rate Limit Middleware - Auth (stricter)
 */
export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,       // 15 minutes
  max: 10,
  message: 'Too many login attempts, please try again later',
  skipSuccessfulRequests: true,
  skipFailedRequests: false,
});

/**
 * Security Headers Middleware
 */
export function securityHeadersMiddleware(req, res, next) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
}

/**
 * Logging Middleware
 */
export function loggingMiddleware(req, res, next) {
  const startTime = Date.now();

  res.on('finish', () => {
    const duration = Date.now() - startTime;
    const logData = {
      requestId: req.id,
      method: req.method,
      path: req.path,
      statusCode: res.statusCode,
      duration: `${duration}ms`,
      userAgent: req.get('user-agent'),
    };

    if (res.statusCode >= 400) {
      logger.error(logData, `${req.method} ${req.path}`);
    } else {
      logger.info(logData, `${req.method} ${req.path}`);
    }
  });

  next();
}

/**
 * Error Handler Middleware (MUST BE LAST)
 */
export function errorHandler(err, req, res, next) {
  let statusCode = 500;
  let code = 'INTERNAL_ERROR';
  let message = 'An unexpected error occurred';

  if (err instanceof AppError) {
    statusCode = err.statusCode;
    code = err.code;
    message = err.message;
  } else {
    logger.error({ error: err, requestId: req.id }, 'Unhandled error');
  }

  return res.status(statusCode).json({
    success: false,
    code,
    message,
    data: null,
    requestId: req.id,
  });
}

/**
 * 404 Handler
 */
export function notFoundHandler(req, res) {
  return res.status(404).json({
    success: false,
    code: 'DATA_NOT_FOUND',
    message: `Route ${req.method} ${req.path} not found`,
    data: null,
    requestId: req.id,
  });
}

export default {
  requestIdMiddleware,
  authenticate,
  validate,
  generalLimiter,
  authLimiter,
  securityHeadersMiddleware,
  loggingMiddleware,
  errorHandler,
  notFoundHandler,
};
