import express from 'express';
import { authenticate, validate } from '../middleware/index.js';
import * as productController from './products.controller.js';
import { createProductSchema, updateProductSchema } from './products.validator.js';

const router = express.Router();

/**
 * List Products
 * GET /api/v1/products?page=1&limit=10
 */
router.get('/', authenticate, productController.listProducts);

/**
 * Get Product Detail
 * GET /api/v1/products/:id
 */
router.get('/:id', authenticate, productController.getProduct);

/**
 * Create Product
 * POST /api/v1/products
 */
router.post(
  '/',
  authenticate,
  validate(createProductSchema),
  productController.createProduct
);

/**
 * Update Product
 * PUT /api/v1/products/:id
 */
router.put(
  '/:id',
  authenticate,
  validate(updateProductSchema),
  productController.updateProduct
);

/**
 * Delete Product
 * DELETE /api/v1/products/:id
 */
router.delete('/:id', authenticate, productController.deleteProduct);

export default router;
