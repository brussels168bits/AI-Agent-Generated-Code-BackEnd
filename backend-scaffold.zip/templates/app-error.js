/**
 * Custom AppError class for API errors
 * Extends Error to provide consistent error handling
 */
export class AppError extends Error {
  constructor(statusCode, code, message) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
    this.name = 'AppError';

    // Capture stack trace (Node.js specific)
    Error.captureStackTrace(this, this.constructor);
  }

  /**
   * Serialize to JSON for logging
   */
  toJSON() {
    return {
      statusCode: this.statusCode,
      code: this.code,
      message: this.message,
      name: this.name,
    };
  }
}

export default AppError;
