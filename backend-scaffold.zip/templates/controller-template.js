import * as productService from './products.service.js';
import { AppError } from '../../utils/app-error.js';

/**
 * List Products
 * GET /api/v1/products
 */
export async function listProducts(req, res, next) {
  try {
    const { page = 1, limit = 10 } = req.query;
    const userContext = req.user;

    const result = await productService.listProducts(
      {
        page: parseInt(page, 10),
        limit: parseInt(limit, 10),
      },
      userContext
    );

    return res.json({
      success: true,
      code: 'SUCCESS',
      message: null,
      data: result.data,
      pagination: result.pagination,
      requestId: req.id,
    });
  } catch (err) {
    next(err);
  }
}

/**
 * Get Product Detail
 * GET /api/v1/products/:id
 */
export async function getProduct(req, res, next) {
  try {
    const { id } = req.params;
    const userContext = req.user;

    const result = await productService.getProduct(id, userContext);

    if (!result.success) {
      return next(new AppError(404, result.code, result.message));
    }

    return res.json({
      success: true,
      code: 'SUCCESS',
      message: null,
      data: result.data,
      requestId: req.id,
    });
  } catch (err) {
    next(err);
  }
}

/**
 * Create Product
 * POST /api/v1/products
 */
export async function createProduct(req, res, next) {
  try {
    const data = req.body;
    const userContext = req.user;

    const result = await productService.createProduct(data, userContext);

    if (!result.success) {
      return next(new AppError(400, result.code, result.message));
    }

    return res.status(201).json({
      success: true,
      code: 'SUCCESS',
      message: null,
      data: result.data,
      requestId: req.id,
    });
  } catch (err) {
    next(err);
  }
}

/**
 * Update Product
 * PUT /api/v1/products/:id
 */
export async function updateProduct(req, res, next) {
  try {
    const { id } = req.params;
    const data = req.body;
    const userContext = req.user;

    const result = await productService.updateProduct(id, data, userContext);

    if (!result.success) {
      const statusCode = result.code === 'CONFLICT' ? 409 : 400;
      return next(new AppError(statusCode, result.code, result.message));
    }

    return res.json({
      success: true,
      code: 'SUCCESS',
      message: null,
      data: result.data,
      requestId: req.id,
    });
  } catch (err) {
    next(err);
  }
}

/**
 * Delete Product
 * DELETE /api/v1/products/:id
 */
export async function deleteProduct(req, res, next) {
  try {
    const { id } = req.params;
    const userContext = req.user;

    const result = await productService.deleteProduct(id, userContext);

    if (!result.success) {
      return next(new AppError(404, result.code, result.message));
    }

    return res.json({
      success: true,
      code: 'SUCCESS',
      message: null,
      data: null,
      requestId: req.id,
    });
  } catch (err) {
    next(err);
  }
}

export default {
  listProducts,
  getProduct,
  createProduct,
  updateProduct,
  deleteProduct,
};
