# 🔄 Refactor Code for Better Performance & Maintainability

**Purpose:** Refactor existing backend code to improve structure, performance, and maintainability

---

## Context

The user will provide:
- Existing backend code (file or module)
- Specific problem areas or performance issues
- Goals (performance, readability, testability, etc.)

You are a Backend Architect tasked with:
1. Analyzing the code for inefficiencies
2. Suggesting refactoring improvements
3. Providing refactored code examples
4. Maintaining the 21 Backend Rules during refactor

---

## Common Refactoring Scenarios

### **Scenario 1: Waterfall API Calls → Parallel**

**Problem:** Sequential API calls causing slow response times

```javascript
// ❌ BAD - Waterfall (900ms total)
const products = await productRepository.findMany(filter);
const categories = await categoryRepository.findMany(filter);
const stats = await statsRepository.getStats(filter);
return { products, categories, stats };
```

**Refactored Solution:**

```javascript
// ✅ GOOD - Parallel (300ms total)
const [products, categories, stats] = await Promise.all([
  productRepository.findMany(filter),
  categoryRepository.findMany(filter),
  statsRepository.getStats(filter),
]);
return { products, categories, stats };
```

**Benefit:** 3x faster (900ms → 300ms)

---

### **Scenario 2: Duplicate Code → Helper Functions**

**Problem:** Same validation/transformation logic repeated

```javascript
// ❌ BAD - Repeated logic
export async function createProduct(data) {
  if (!data.name || data.name.trim() === '') {
    return { success: false, code: 'INVALID_PARAM', message: 'Name required' };
  }
  if (data.price < 0) {
    return { success: false, code: 'INVALID_PARAM', message: 'Price must be positive' };
  }
  // ... similar validation in 3 other endpoints
}
```

**Refactored Solution:**

```javascript
// ✅ GOOD - Centralized validation
function validateProductData(data) {
  const errors = [];
  if (!data.name?.trim()) errors.push('Name required');
  if (data.price < 0) errors.push('Price must be positive');
  return errors.length > 0 ? { isValid: false, errors } : { isValid: true };
}

export async function createProduct(data) {
  const validation = validateProductData(data);
  if (!validation.isValid) {
    return { success: false, code: 'INVALID_PARAM', message: validation.errors.join(', ') };
  }
  // ... rest of logic
}
```

**Benefit:** DRY principle, easier maintenance

---

### **Scenario 3: Missing Indexes → Add Proper Indexes**

**Problem:** Slow queries due to missing or wrong indexes

```javascript
// ❌ BAD - No index
db.collection('products').find({
  ou_id: ObjectId(ouId),
  branch_id: ObjectId(branchId),
  status: 'active',
}).toArray();  // Full collection scan!
```

**Refactored Solution:**

```javascript
// ✅ GOOD - ESR Index
await createCollectionIndexes('products', [
  {
    name: 'idx_ou_id_branch_id_status',
    key: { ou_id: 1, branch_id: 1, status: 1 }
  }
]);

db.collection('products').find({
  ou_id: ObjectId(ouId),
  branch_id: ObjectId(branchId),
  status: 'active',
}).toArray();  // Uses index!
```

**Benefit:** 10-100x faster queries

---

### **Scenario 4: Fat Controller → Proper Layer Separation**

**Problem:** Business logic in controller instead of service

```javascript
// ❌ BAD - Controller does everything
export async function createProduct(req, res, next) {
  try {
    const { body: data } = req;
    
    // Business logic here! ❌
    if (!data.name) throw new Error('Name required');
    
    const existing = await db.collection('products').findOne({
      product_code: data.product_code,
      ou_id: req.user.ou_id,
    });
    if (existing) throw new Error('Already exists');
    
    // DB access here! ❌
    const result = await db.collection('products').insertOne({
      ...data,
      ou_id: req.user.ou_id,
    });
    
    res.json({ success: true, data: result });
  } catch (err) {
    next(err);
  }
}
```

**Refactored Solution:**

```javascript
// ✅ GOOD - Proper separation
// Controller (HTTP orchestration)
export async function createProduct(req, res, next) {
  try {
    const result = await productService.createProduct(req.body, req.user);
    if (!result.success) return next(new AppError(400, result.code, result.message));
    res.status(201).json({ success: true, data: result.data, requestId: req.id });
  } catch (err) {
    next(err);
  }
}

// Service (Business logic)
export async function createProduct(data, userContext) {
  if (!data.name) {
    return { success: false, code: 'INVALID_PARAM', message: 'Name required' };
  }
  const existing = await productRepository.findByCode(data.product_code, userContext);
  if (existing) {
    return { success: false, code: 'CONFLICT', message: 'Already exists' };
  }
  return await productRepository.create(data, userContext);
}

// Repository (DB access)
export async function create(data, userContext) {
  const client = getClient();
  const session = client.startSession();
  try {
    let result;
    await session.withTransaction(async () => {
      // Only DB operations here
      const insertResult = await db.collection('products').insertOne(payload, { session });
      await db.collection('product_logs').insertOne(logPayload, { session });
      result = insertResult;
    });
    return result;
  } finally {
    await session.endSession();
  }
}
```

**Benefit:** Testable, maintainable, follows 4-layer pattern

---

### **Scenario 5: Error Handling → Comprehensive Error Handling**

**Problem:** Incomplete error handling

```javascript
// ❌ BAD - No error context
catch (err) {
  res.status(500).json({ error: err.message });
}

// ❌ BAD - Swallowed errors
const result = await service.create(data);
// What if it fails silently?
```

**Refactored Solution:**

```javascript
// ✅ GOOD - Structured error handling
export async function createProduct(req, res, next) {
  try {
    const result = await productService.createProduct(req.body, req.user);
    
    // Check result structure
    if (!result.success) {
      return next(new AppError(
        result.statusCode || 400,
        result.code,
        result.message
      ));
    }
    
    res.status(201).json({
      success: true,
      code: 'SUCCESS',
      message: null,
      data: result.data,
      requestId: req.id,
    });
  } catch (err) {
    // All errors go here
    next(err);
  }
}

// Global error handler
export function errorHandler(err, req, res, next) {
  let statusCode = 500;
  let code = 'INTERNAL_ERROR';
  let message = 'An unexpected error occurred';
  
  if (err instanceof AppError) {
    statusCode = err.statusCode;
    code = err.code;
    message = err.message;
  } else {
    logger.error({ error: err, requestId: req.id }, 'Unhandled error');
  }
  
  res.status(statusCode).json({
    success: false,
    code,
    message,
    data: null,
    requestId: req.id,
  });
}
```

**Benefit:** Proper error tracking, debugging support

---

### **Scenario 6: Raw SQL Logging → Structured Logging**

**Problem:** Using console.log or no logging

```javascript
// ❌ BAD
console.log('Product created:', productId);
console.error('Error:', error);
```

**Refactored Solution:**

```javascript
// ✅ GOOD - Structured logging with context
import { logger } from '../../utils/logger.js';

// In repository
const result = await db.collection('products').insertOne(payload, { session });
logger.info(
  { productId: result.insertedId.toString(), ou_id: payload.ou_id },
  'Product created'
);

// In error handler
logger.error(
  {
    error,
    requestId: req.id,
    userId: req.user?.username,
    path: req.path,
    method: req.method,
  },
  'Request failed'
);
```

**Benefit:** Searchable logs, better debugging, monitoring

---

### **Scenario 7: N+1 Query Problem → Batch or Cache**

**Problem:** Loop making individual queries (N+1)

```javascript
// ❌ BAD - N+1 queries
const products = await productRepository.findMany(filter);
const response = await Promise.all(
  products.map(async (p) => ({
    ...p,
    category: await categoryRepository.findOne(p.category_id), // 1 query per product!
  }))
);
```

**Refactored Solution:**

```javascript
// ✅ GOOD - Single batch query
const products = await productRepository.findMany(filter);
const categoryIds = [...new Set(products.map(p => p.category_id))];
const categories = await categoryRepository.findMany({
  _id: { $in: categoryIds },
  ...tenantFilter(userContext),
});

const categoryMap = new Map(categories.map(c => [c._id.toString(), c]));

const response = products.map(p => ({
  ...p,
  category: categoryMap.get(p.category_id.toString()),
}));
```

**Benefit:** From N+1 queries to 2 queries (for N products)

---

### **Scenario 8: Missing Audit Trail → Add Audit Logging**

**Problem:** No audit log for changes

```javascript
// ❌ BAD - No audit trail
await db.collection('products').updateOne(filter, { $set: updatePayload });
```

**Refactored Solution:**

```javascript
// ✅ GOOD - Audit trail included
const client = getClient();
const session = client.startSession();

try {
  await session.withTransaction(async () => {
    const oldDoc = await db.collection('products').findOne(filter, { session });
    
    // Update main document
    await db.collection('products').updateOne(filter, { $set: updatePayload }, { session });
    
    // Log changes
    const changedFields = {};
    Object.keys(updatePayload).forEach(key => {
      if (oldDoc[key] !== updatePayload[key]) {
        changedFields[key] = { old: oldDoc[key], new: updatePayload[key] };
      }
    });
    
    await db.collection('product_logs').insertOne({
      action: 'UPDATE',
      changed_fields: changedFields,
      snapshot_data: { old: oldDoc, new: { ...oldDoc, ...updatePayload } },
      ref_id: oldDoc._id,
      ou_id: oldDoc.ou_id,
      branch_id: oldDoc.branch_id,
      cr_by: userContext.username,
      cr_date: new Date(),
      cr_prog: '/api/v1/products',
    }, { session });
  });
} finally {
  await session.endSession();
}
```

**Benefit:** Full audit trail, compliance, debugging

---

## Refactoring Checklist

Before and after refactoring, verify:

- [ ] **Performance**: Parallel calls where possible
- [ ] **DRY**: No duplicate code
- [ ] **4-Layer Separation**: Route → Controller → Service → Repository
- [ ] **Error Handling**: Comprehensive, structured
- [ ] **Logging**: No console.log, use logger
- [ ] **Audit Trail**: All changes logged
- [ ] **Indexes**: Proper ESR indexes
- [ ] **Tenant Isolation**: Every query filtered
- [ ] **Optimistic Locking**: Update/delete versioned
- [ ] **21 Rules**: All followed

---

## Output Format

Provide:

1. **Analysis** - What's wrong and why
2. **Refactored Code** - Complete improved version
3. **Before/After Comparison** - Side-by-side
4. **Benefits** - Performance/maintainability gains
5. **Migration Steps** - How to apply refactoring
6. **Testing** - How to verify it works

---

**Refactor code to follow best practices while maintaining 21 Backend Rules.**
