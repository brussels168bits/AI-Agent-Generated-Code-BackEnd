# 🆕 Add New Module to Existing Project

**Purpose:** Add a complete new module (CRUD) to an existing backend project

---

## Context

The user has an existing Node.js + MongoDB backend project and wants to add a new module/resource.

You are a Backend Architecture Expert tasked with:
1. Creating all 5 required files for a new module
2. Following the 21 Backend Rules strictly
3. Integrating with existing codebase
4. Providing clear instructions for final steps

---

## Instructions

### **1. Gather Requirements**

Ask the user:
- **Module name** - What resource? (e.g., "products", "user-accounts", "bank-branches")
- **Fields** - What data does it store? (e.g., name, code, price, quantity)
- **Relations** - Does it relate to other modules? (e.g., products belong to categories)
- **Special logic** - Any business rules? (e.g., price must be > 0, code must be unique)

---

### **2. Generate 5 Files**

For module `<module-name>`, create:

#### **File 1: <module-name>.validator.js**
```javascript
import Joi from 'joi';

export const create<Module>Schema = Joi.object({
  <field1>: Joi.string().required(),
  <field2>: Joi.number().min(0).required(),
  // ... all fields
}).unknown(false);

export const update<Module>Schema = Joi.object({
  <field1>: Joi.string().optional(),
  <field2>: Joi.number().min(0).optional(),
}).unknown(false);
```

- Use snake_case for field names (matching DB)
- Validate all business rules
- Separate create/update schemas

#### **File 2: <module-name>.repository.js**
```javascript
import { ObjectId, Decimal128 } from 'mongodb';
import { getDatabase, tenantFilter, serializeDoc } from '../../config/database.js';

export async function findOne(id, userContext) {
  const db = getDatabase();
  const doc = await db.collection('<module>s').findOne({
    _id: new ObjectId(id),
    ...tenantFilter(userContext),
  });
  return doc ? { id: doc._id.toString(), ...serializeDoc(doc) } : null;
}

// ... other CRUD methods with transactions + audit logging
```

- Include tenantFilter in every query
- Use transactions for CREATE/UPDATE/DELETE
- Insert audit logs
- Check optimistic locking for update/delete

#### **File 3: <module-name>.service.js**
```javascript
import * as <module>Repository from './<module>.repository.js';
import { logger } from '../../utils/logger.js';

export async function create<Module>(data, userContext) {
  try {
    // Business logic validation
    if (!data.<field>) {
      return { success: false, code: 'INVALID_PARAM', message: '...' };
    }
    
    // Check duplicates if needed
    const existing = await <module>Repository.findByCode(data.<code>, userContext);
    if (existing) {
      return { success: false, code: 'CONFLICT', message: '...' };
    }
    
    // Create via repository
    const created = await <module>Repository.create(data, userContext);
    return { success: true, code: 'SUCCESS', message: null, data: created };
  } catch (error) {
    logger.error({ error }, 'Error creating <module>');
    throw error;
  }
}

// ... other CRUD methods
```

- Validate business rules
- Return { success, code, message, data }
- Call repository only
- Handle errors gracefully

#### **File 4: <module-name>.controller.js**
```javascript
import * as <module>Service from './<module>.service.js';
import { AppError } from '../../utils/app-error.js';

export async function create<Module>(req, res, next) {
  try {
    const data = req.body;
    const userContext = req.user;
    
    const result = await <module>Service.create<Module>(data, userContext);
    
    if (!result.success) {
      return next(new AppError(400, result.code, result.message));
    }
    
    return res.status(201).json({
      success: true,
      code: 'SUCCESS',
      message: null,
      data: result.data,
      requestId: req.id,
    });
  } catch (err) {
    next(err);
  }
}

// ... other CRUD methods
```

- Orchestrate service calls
- Format HTTP response
- Pass errors to next(err)
- Include requestId in response

#### **File 5: <module-name>.route.js**
```javascript
import express from 'express';
import { authenticate, validate } from '../middleware/index.js';
import * as <module>Controller from './<module>.controller.js';
import { create<Module>Schema, update<Module>Schema } from './<module>.validator.js';

const router = express.Router();

router.get('/', authenticate, <module>Controller.list<Module>s);
router.get('/:id', authenticate, <module>Controller.get<Module>);
router.post('/', authenticate, validate(create<Module>Schema), <module>Controller.create<Module>);
router.put('/:id', authenticate, validate(update<Module>Schema), <module>Controller.update<Module>);
router.delete('/:id', authenticate, <module>Controller.delete<Module>);

export default router;
```

- Define REST endpoints
- Attach authentication
- Attach validation
- Call controller methods

---

### **3. Check Against 21 Rules**

Verify:
- [ ] Rule 1: Tenant isolation in every query
- [ ] Rule 2: Optimistic locking in update/delete
- [ ] Rule 3: Audit fields (cr_*, upd_*)
- [ ] Rule 4: No Mongoose (native driver)
- [ ] Rule 5: No hardcode (ENV vars)
- [ ] Rule 6: Correct HTTP status codes
- [ ] Rule 7: ISO 8601 datetime
- [ ] Rule 8: Money as Decimal128 → String
- [ ] Rule 9: findOne() for detail (not find().toArray()[0])
- [ ] Rule 10: ESR index order
- [ ] Rule 11: Global error handler (next(err))
- [ ] Rule 12: RequestId in response
- [ ] Rule 13: JWT decode in middleware
- [ ] Rule 14: Soft delete (is_deleted flag)
- [ ] Rule 15: Transaction + Log together
- [ ] Rule 16: CRUD pattern (Route → Controller → Service → Repository)
- [ ] Rule 17: Validate middleware
- [ ] Rule 18: Logger (Pino) only
- [ ] Rule 19: Middleware order
- [ ] Rule 20: Decimal128 → String
- [ ] Rule 21: ESM only (import/export)

---

### **4. Database Setup**

Provide MongoDB collection schema:
```javascript
// Collection: <module>s
{
  _id: ObjectId,
  // Tenant fields
  ou_id: ObjectId,
  branch_id: ObjectId,
  is_deleted: Boolean,
  // Business fields
  <field1>: String,
  <field2>: Decimal128,
  // Audit fields
  cr_by: String,
  cr_date: Date,
  cr_prog: String,
  upd_by: String,
  upd_date: Date,
  upd_prog: String,
  deleted_by: String | null,
  deleted_date: Date | null,
  deleted_prog: String | null,
}
```

Provide index creation:
```javascript
await createCollectionIndexes('<module>s', [
  {
    name: 'idx_ou_id_branch_id_is_deleted',
    key: { ou_id: 1, branch_id: 1, is_deleted: 1 }
  },
  {
    name: 'idx_ou_id_branch_id_is_deleted_<field>',
    key: { ou_id: 1, branch_id: 1, is_deleted: 1, <field>: 1 }
  }
]);
```

---

### **5. Integration Steps**

Provide clear instructions:

1. **Create folder:**
   ```bash
   mkdir src/modules/<module-name>
   ```

2. **Add files** - Copy the 5 generated files

3. **Update app.js:**
   ```javascript
   import <module>Routes from './modules/<module-name>/<module-name>.route.js';
   app.use('/api/v1/<module>s', <module>Routes);
   ```

4. **Create indexes** (in database initialization):
   ```javascript
   await createCollectionIndexes('<module>s', [...]);
   ```

5. **Test endpoints:**
   ```bash
   curl -X GET http://localhost:3000/api/v1/<module>s \
     -H "Authorization: Bearer <token>"
   ```

---

### **6. Output Format**

Provide:
1. All 5 source files (complete, ready to copy-paste)
2. Database schema
3. Index creation code
4. Integration instructions (step-by-step)
5. Testing curl commands
6. Checklist of all 21 rules verified

---

## Naming Convention Reminder

- Files: `kebab-case.js`
- Variables/Functions: `camelCase`
- Database fields: `snake_case`
- API response fields: `camelCase`
- Routes: `/api/v1/<plural-kebab-case>`

---

## Common Patterns

**Unique field validation:**
```javascript
const existing = await productRepository.findByCode(data.product_code, userContext);
if (existing) return { success: false, code: 'CONFLICT', message: '...' };
```

**Decimal money field:**
```javascript
price: Decimal128.fromString(String(data.price))
```

**Soft delete:**
```javascript
is_deleted: true,
deleted_by: userContext.username,
deleted_date: now,
deleted_prog: '/api/v1/products',
upd_by: userContext.username,
upd_date: now,
upd_prog: '/api/v1/products',
```

---

**Generate complete, production-ready code that can be copy-pasted immediately.**
