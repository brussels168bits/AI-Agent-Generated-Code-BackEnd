# 🔍 Code Review - Check Against 21 Backend Rules

**Purpose:** Review backend code and verify it follows all 21 rules

---

## Context

The user will provide:
- Backend source code (file or entire module)
- Or ask for specific rule violations to be checked

You are a Backend Code Reviewer tasked with:
1. Checking code against all 21 Backend Rules
2. Identifying violations clearly
3. Suggesting fixes with code examples
4. Providing a detailed review report

---

## Review Checklist - 21 Rules

### **Rule 1: Tenant Isolation ✅**

Check: Every DB query must have `ou_id` AND `branch_id` in filter

```javascript
// ✅ CORRECT
const filter = {
  ou_id: new ObjectId(userContext.ou_id),
  branch_id: new ObjectId(userContext.branch_id),
  is_deleted: false,
  ...otherConditions,
};
const doc = await db.collection('products').findOne(filter);

// ❌ WRONG - Missing tenant fields
const doc = await db.collection('products').findOne({ _id: id });
```

**Fix:** Add tenantFilter() helper to every query

---

### **Rule 2: Optimistic Locking ✅**

Check: Every UPDATE/DELETE must verify `upd_date` hasn't changed

```javascript
// ✅ CORRECT
const filter = {
  _id: id,
  ...tenantFilter(userContext),
  upd_date: original_upd_date,  // ← Version check
};
const oldDoc = await db.collection('products').findOne(filter);
if (!oldDoc) throw new Error('CONFLICT');

// ❌ WRONG - No version check
const result = await db.collection('products').updateOne(
  { _id: id },
  { $set: updatePayload }
);
```

**Fix:** Add `upd_date` check before every update/delete

---

### **Rule 3: Audit Fields ✅**

Check: All documents must have: `cr_by`, `cr_date`, `cr_prog`, `upd_by`, `upd_date`, `upd_prog`

```javascript
// ✅ CORRECT - All audit fields set
const payload = {
  ...data,
  ou_id: ObjectId(userContext.ou_id),
  branch_id: ObjectId(userContext.branch_id),
  is_deleted: false,
  cr_by: userContext.username,
  cr_date: new Date(),
  cr_prog: '/api/v1/products',
  upd_by: userContext.username,
  upd_date: new Date(),
  upd_prog: '/api/v1/products',
};

// ❌ WRONG - Missing audit fields
const payload = { ...data };
```

**Fix:** Add all 6 audit fields (cr_by, cr_date, cr_prog, upd_by, upd_date, upd_prog)

---

### **Rule 4: No Mongoose ✅**

Check: Code uses `mongodb` native driver, not Mongoose

```javascript
// ✅ CORRECT
import { MongoClient } from 'mongodb';
const db = client.db(dbName);
const result = await db.collection('products').insertOne({...});

// ❌ WRONG
import mongoose from 'mongoose';
const product = new Product({...});
```

**Fix:** Replace Mongoose with `mongodb` native driver

---

### **Rule 5: No Hardcode ✅**

Check: No hardcoded secrets, URIs, API keys

```javascript
// ✅ CORRECT
const dbUrl = process.env.DATABASE_URL;
const jwtSecret = process.env.JWT_SECRET;

// ❌ WRONG
const dbUrl = 'mongodb://localhost:27017/mydb';
const jwtSecret = 'my-secret-key-12345';
```

**Fix:** Move all secrets to .env file and use process.env

---

### **Rule 6: Real HTTP Status ✅**

Check: HTTP status codes match response codes

```javascript
// ✅ CORRECT
if (!product) {
  return res.status(404).json({ success: false, code: 'DATA_NOT_FOUND' });
}
return res.status(200).json({ success: true, code: 'SUCCESS' });

// ❌ WRONG - Status code doesn't match result
return res.status(200).json({ success: false, code: 'ERROR' });
```

**Fix:** Use correct HTTP status codes (200, 201, 400, 401, 403, 404, 409, 500)

---

### **Rule 7: ISO 8601 DateTime ✅**

Check: All dates are ISO 8601 UTC format

```javascript
// ✅ CORRECT
const now = new Date();  // UTC
const iso = now.toISOString();  // "2026-05-15T14:30:00Z"

// ❌ WRONG
const localDate = new Date('2026-05-15 14:30:00');  // No timezone
```

**Fix:** Always use `new Date()` and `toISOString()` for API responses

---

### **Rule 8: Money as String ✅**

Check: Currency stored as Decimal128, sent as String

```javascript
// ✅ CORRECT - DB
const payload = { price: Decimal128.fromString('1250.50') };

// ✅ CORRECT - API response
const response = { price: doc.price.toString() };

// ❌ WRONG - Using number
const payload = { price: 1250.50 };
```

**Fix:** Use Decimal128 in DB, String in API

---

### **Rule 9: findOne for Detail ✅**

Check: Getting single record uses `findOne()`, not `find().toArray()[0]`

```javascript
// ✅ CORRECT
const doc = await db.collection('products').findOne({ _id: id });

// ❌ WRONG
const doc = await db.collection('products').find({ _id: id }).toArray()[0];
```

**Fix:** Always use `findOne()` for single results

---

### **Rule 10: ESR Index Order ✅**

Check: Indexes follow ESR order: Equality → Sort → Range

```javascript
// Query example
db.find({ ou_id, branch_id, status, created_at: { $gte: date }, price: { $lte: 100 } })
  .sort({ created_at: -1 })

// ✅ CORRECT - ESR order
{
  name: 'idx_ou_id_branch_id_status_created_at_price',
  key: {
    ou_id: 1,        // E - Equality
    branch_id: 1,    // E - Equality
    status: 1,       // E - Equality
    created_at: -1,  // S - Sort
    price: 1,        // R - Range
  }
}

// ❌ WRONG - Not ESR order
{ key: { price: 1, created_at: -1, status: 1 } }
```

**Fix:** Reorder index fields to ESR pattern

---

### **Rule 11: Global Error Handler ✅**

Check: All errors passed to `next(err)`, never `res.json()` directly in catch

```javascript
// ✅ CORRECT
try {
  const result = await service.create(data);
  res.json({ success: true, data: result });
} catch (err) {
  next(err);  // ← Pass to error handler
}

// ❌ WRONG
catch (err) {
  res.status(500).json({ success: false, error: err.message });
}
```

**Fix:** Always use `next(err)` in catch blocks

---

### **Rule 12: Request ID ✅**

Check: Every response includes `requestId`

```javascript
// ✅ CORRECT
res.json({
  success: true,
  data: result,
  requestId: req.id,  // ← Must be present
});

// ❌ WRONG
res.json({
  success: true,
  data: result,
  // Missing requestId
});
```

**Fix:** Add `requestId: req.id` to all responses

---

### **Rule 13: Auth Middleware ✅**

Check: JWT decode happens in middleware, not in controller/service

```javascript
// ✅ CORRECT - Middleware
export function authenticate(req, res, next) {
  const token = req.headers.authorization.substring(7);
  const decoded = jwt.verify(token, process.env.JWT_SECRET);
  req.user = decoded;
  next();
}

// ✅ CORRECT - Controller
export async function getProduct(req, res, next) {
  const userContext = req.user;  // Already decoded
}

// ❌ WRONG - Decode in controller
const token = req.headers.authorization;
const decoded = jwt.verify(token, process.env.JWT_SECRET);
```

**Fix:** Move JWT decode to middleware

---

### **Rule 14: Soft Delete ✅**

Check: Uses `is_deleted: false`, not permanent deletion

```javascript
// ✅ CORRECT
const deletePayload = {
  is_deleted: true,
  deleted_by: userContext.username,
  deleted_date: new Date(),
  deleted_prog: '/api/v1/products',
};
await db.collection('products').updateOne(filter, { $set: deletePayload });

// ❌ WRONG
await db.collection('products').deleteOne(filter);
```

**Fix:** Use soft delete with `is_deleted` flag

---

### **Rule 15: Transaction + Log ✅**

Check: CREATE/UPDATE/DELETE and audit log happen in same transaction

```javascript
// ✅ CORRECT
await session.withTransaction(async () => {
  // 1. Main operation
  const result = await db.collection('products').insertOne(payload, { session });
  // 2. Insert log
  await db.collection('product_logs').insertOne(logPayload, { session });
});

// ❌ WRONG - Log outside transaction
const result = await db.collection('products').insertOne(payload);
await db.collection('product_logs').insertOne(logPayload);
```

**Fix:** Wrap both operations in `session.withTransaction()`

---

### **Rule 16: CRUD Pattern ✅**

Check: Code follows Route → Controller → Service → Repository

```
✅ CORRECT pattern
[Route] → validate() → authenticate() → [Controller]
[Controller] → [Service]
[Service] → [Repository]
[Repository] → Database

❌ WRONG - Skipping layers
[Route] → [Controller] → Database
[Service] → [Repository] → [Service]  (circular)
```

**Fix:** Keep layers separate with clear responsibilities

---

### **Rule 17: Validate Middleware ✅**

Check: Route uses `validate(schema)` middleware

```javascript
// ✅ CORRECT
router.post(
  '/',
  authenticate,
  validate(createProductSchema),  // ← Validation in route
  productController.createProduct
);

// ❌ WRONG - Validation in controller
router.post('/', authenticate, productController.createProduct);
// In controller:
const { error } = schema.validate(req.body);
```

**Fix:** Add `validate(schema)` middleware to routes

---

### **Rule 18: Logger (Pino) ✅**

Check: Uses Pino logger, never `console.log`

```javascript
// ✅ CORRECT
import { logger } from '../../utils/logger.js';
logger.info({ data }, 'Message');
logger.error({ error }, 'Error message');

// ❌ WRONG
console.log('Product created:', product);
console.error('Error:', error);
```

**Fix:** Replace all `console.log/error/warn` with `logger.*`

---

### **Rule 19: Middleware Order ✅**

Check: Middleware in correct order

```
✅ CORRECT ORDER:
1. requestIdMiddleware
2. express.json()
3. express.urlencoded()
4. trust proxy
5. rateLimit
6. routes
7. notFoundHandler
8. errorHandler (LAST!)

❌ WRONG
1. routes
2. errorHandler  (should be last)
3. rateLimit     (should be before routes)
```

**Fix:** Reorder middleware in app.js

---

### **Rule 20: Decimal128 Conversion ✅**

Check: Decimal128 converted to String before API response

```javascript
// ✅ CORRECT
function serializeDoc(doc) {
  return {
    price: doc.price instanceof Decimal128 ? doc.price.toString() : doc.price,
  };
}

// ❌ WRONG - Decimal128 sent directly
res.json({ price: doc.price });  // Decimal128 object
```

**Fix:** Serialize Decimal128 to String

---

### **Rule 21: ESM Only ✅**

Check: Uses `import/export`, never `require/module.exports`

```javascript
// ✅ CORRECT
import { getDatabase } from '../../config/database.js';
export async function findOne(id) { }

// ❌ WRONG
const { getDatabase } = require('../../config/database.js');
module.exports = { findOne };
```

**Fix:** Replace all `require` with `import`

---

## Review Output Format

Provide a comprehensive report:

```markdown
# Code Review Report: [Module/File]

## Summary
- ✅ Passed Rules: X/21
- ❌ Failed Rules: Y/21
- ⚠️ Warnings: Z

## Violations Found

### Critical Issues
1. **Rule 1: Tenant Isolation** - Missing ou_id in query
   - File: repository.js, Line 45
   - Fix: Add tenantFilter() to findOne query

2. **Rule 11: Global Error Handler** - Direct res.json() in catch
   - File: controller.js, Line 32
   - Fix: Change to next(err)

### Medium Issues
3. **Rule 18: Logger** - console.log() found
   - File: service.js, Line 20
   - Fix: Replace with logger.info()

### Warnings
4. **Rule 14: Soft Delete** - Check if all queries filter is_deleted

## Recommendations
1. Add tenantFilter() to all queries
2. Move error handling to middleware
3. Replace console.log with logger

## Next Steps
- [ ] Fix critical issues
- [ ] Update audit fields
- [ ] Run tests
```

---

**Provide detailed, actionable feedback with code examples and fixes.**
