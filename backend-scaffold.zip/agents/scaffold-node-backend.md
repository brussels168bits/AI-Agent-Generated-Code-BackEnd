# 🚀 Backend Scaffolding Prompt

**Purpose:** Generate complete Node.js + MongoDB backend project structure

---

## Context

You are a Backend Architecture Expert. Your task is to scaffold a new Node.js + MongoDB backend project that strictly follows **21 Critical Backend Rules** and maintains best practices.

The user will specify:
- Project name
- Modules/resources to create
- Additional requirements

---

## Instructions

### **1. Create Folder Structure**
```
Generate the following structure:

src/
├── config/
│   └── database.js           (MongoDB connection)
│   └── logger.js             (Pino logger)
├── modules/                  (One folder per module)
│   ├── [module1]/
│   │   ├── [module1].route.js
│   │   ├── [module1].controller.js
│   │   ├── [module1].service.js
│   │   ├── [module1].repository.js
│   │   └── [module1].validator.js
│   └── [module2]/
│       └── (same structure)
├── middleware/
│   ├── index.js              (exports all middleware)
│   ├── authenticate.js       (JWT validation)
│   ├── validate.js           (Joi schema validation)
│   ├── errorHandler.js       (Global error handling)
│   └── rateLimit.js          (Rate limiting)
├── utils/
│   ├── app-error.js          (Custom error class)
│   ├── logger.js             (Pino logger setup)
│   └── format.js             (serialization + formatting)
├── app.js                    (Express app setup)
├── server.js                 (Server entry point)
├── package.json              (Dependencies)
├── .env.example              (Environment template)
├── .env                      (Development config)
├── docker-compose.yml        (MongoDB setup)
└── STANDARDS.md              (Backend Rules reference)
```

---

### **2. Must Follow 21 Backend Rules**

| Rule | What to Check |
|------|---------------|
| 1 | **Tenant Isolation** - Every query has `ou_id`, `branch_id`, `is_deleted` |
| 2 | **Optimistic Locking** - UPDATE/DELETE check `upd_date` |
| 3 | **Audit Fields** - All docs have `cr_*`, `upd_*` fields |
| 4 | **No Mongoose** - Use native `mongodb` driver only |
| 5 | **No Hardcode** - All secrets from ENV vars |
| 6 | **Real HTTP Status** - 200 success, 400 bad request, 401 auth, etc. |
| 7 | **ISO 8601 DateTime** - Always UTC ISO string format |
| 8 | **Money as String** - DB=Decimal128, API=String |
| 9 | **findOne for Detail** - Never use find().toArray()[0] |
| 10 | **ESR Index Order** - Equality → Sort → Range |
| 11 | **Global Error Handler** - All errors via next(err) |
| 12 | **Request ID** - Every request gets unique ID |
| 13 | **Auth Middleware** - JWT decode in middleware only |
| 14 | **Soft Delete** - Use `is_deleted: false` flag |
| 15 | **Transaction** - CREATE/UPDATE/DELETE + LOG in one transaction |
| 16 | **CRUD Pattern** - Route → Controller → Service → Repository |
| 17 | **Validate Middleware** - Use validate(schema) in routes |
| 18 | **Logger (Pino)** - Never console.log |
| 19 | **Middleware Order** - requestId → body → proxy → rateLimit → routes → 404 → errorHandler |
| 20 | **Decimal128** - Convert to String before API response |
| 21 | **ESM Only** - import/export only, no require |

---

### **3. Create Files for Each Module**

For each module, generate:

#### **Route File** (`<module>.route.js`)
- Import controller methods
- Import validation schemas
- Define REST endpoints (GET list, GET detail, POST, PUT, DELETE)
- Attach authenticate middleware
- Attach validate middleware
- Return all HTTP 2xx/4xx/5xx status codes correctly

#### **Controller File** (`<module>.controller.js`)
- Export async functions for each route
- Get req.user (from middleware) and req.body (validated)
- Call service methods
- Send response with: `{ success, code, message, data, requestId }`
- Pass all errors to `next(err)` - never res.json() directly on error

#### **Service File** (`<module>.service.js`)
- Export async functions for business logic
- Validate business rules
- Call repository methods only
- Return `{ success, code, message, data }`
- Handle errors gracefully

#### **Repository File** (`<module>.repository.js`)
- Export async functions for DB access
- Include `tenantFilter()` in every query
- Use `findOne()` for single results (not find().toArray()[0])
- Use transactions for CREATE/UPDATE/DELETE + LOG
- Include optimistic locking checks for UPDATE/DELETE
- Convert Decimal128 → String in serializeDoc()

#### **Validator File** (`<module>.validator.js`)
- Export Joi schemas
- Schema names: `create<Module>Schema`, `update<Module>Schema`
- Validate all required fields
- Use snake_case field names (matching database)

---

### **4. Naming Conventions**

**Strict Rules:**
- Variables/Functions: `camelCase`
- Classes: `PascalCase`
- Constants: `UPPER_SNAKE_CASE`
- **Database Fields: `snake_case`** (CRITICAL)
- **API Response Fields: `camelCase`** (CRITICAL)
- Files: `kebab-case.js`
- Folders: `kebab-case`
- Routes: `/api/v1/<kebab-case-plural-resource>`

---

### **5. API Response Format**

**All responses must follow:**
```json
{
  "success": boolean,
  "code": "SUCCESS|ERROR_CODE",
  "message": null | "User message",
  "data": {} | [] | null,
  "pagination": { "page", "limit", "total", "totalPages" },
  "requestId": "uuid"
}
```

**HTTP Status Map:**
- 200 OK: `SUCCESS` or `DATA_NOT_FOUND`
- 201 Created: `SUCCESS`
- 400 Bad Request: `INVALID_PARAM`, `INVALID_HEADER`
- 401 Unauthorized: `UNAUTHORIZED`, `TOKEN_EXPIRED`
- 403 Forbidden: `MISSING_AUTHORIZATION`
- 404 Not Found: `DATA_NOT_FOUND`
- 409 Conflict: `CONFLICT`
- 429 Too Many: `TOO_MANY_REQUESTS`
- 500 Server Error: `INTERNAL_ERROR`

---

### **6. Database Setup**

**Collections must have:**
```javascript
{
  _id: ObjectId,                    // MongoDB ID
  ou_id: ObjectId,                  // Organization
  branch_id: ObjectId,              // Branch
  is_deleted: Boolean,              // Soft delete flag
  // Business fields
  ...fields,
  // Audit fields (CREATE)
  cr_by: String,                    // Created by (username)
  cr_date: Date,                    // Created date (UTC)
  cr_prog: String,                  // Created program (API path)
  // Audit fields (UPDATE)
  upd_by: String,                   // Updated by
  upd_date: Date,                   // Updated date (UTC)
  upd_prog: String,                 // Updated program
  // Soft delete
  deleted_by: String | null,
  deleted_date: Date | null,
  deleted_prog: String | null,
}
```

**Indexes:**
```javascript
// Base index for every collection
{
  name: 'idx_ou_id_branch_id_is_deleted',
  key: { ou_id: 1, branch_id: 1, is_deleted: 1 }
}
```

---

### **7. Key Files to Create**

**app.js:**
- Setup Express with middleware in order
- Middleware order: requestId → json → urlencoded → trust proxy → rateLimit → routes → 404 → errorHandler
- Mount routes at `/api/v1/<resource>`

**server.js:**
- Initialize database
- Start server on process.env.PORT
- Graceful shutdown

**config/database.js:**
- MongoDB connection setup
- Export: getDatabase(), getClient(), serializeDoc(), tenantFilter()
- Health check function

**middleware/index.js:**
- requestIdMiddleware - assigns req.id
- authenticate - JWT decode
- validate(schema) - Joi validation
- errorHandler - global error handling
- notFoundHandler - 404 responses

**utils/app-error.js:**
```javascript
class AppError extends Error {
  constructor(statusCode, code, message) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
  }
}
```

**utils/logger.js:**
- Pino logger setup
- Export: logger.info(), logger.error(), logger.debug()

---

### **8. Environment Variables**

Create `.env.example`:
```
NODE_ENV=development
PORT=3000
DATABASE_URL=mongodb://localhost:27017
DATABASE_NAME=my-api
DATABASE_REPLICA_SET=rs0
JWT_SECRET=your-secret-key
JWT_EXPIRATION_DAYS=7
LOG_LEVEL=info
CORS_ORIGIN=http://localhost:3001
```

---

### **9. Docker Compose**

Create `docker-compose.yml` for MongoDB:
```yaml
version: '3.8'
services:
  mongodb:
    image: mongo:8.0
    ports:
      - '27017:27017'
    environment:
      MONGO_INITDB_ROOT_USERNAME: admin
      MONGO_INITDB_ROOT_PASSWORD: password
    volumes:
      - mongo-data:/data/db
    command: --replSet rs0

volumes:
  mongo-data:
```

---

### **10. Validation**

Verify generated code:
- ✅ No `require()` - only `import/export`
- ✅ No `console.log()` - only `logger.*`
- ✅ No direct `res.json()` in errors - only `next(err)`
- ✅ All DB queries have `tenantFilter()`
- ✅ All UPDATE/DELETE check `upd_date`
- ✅ All API responses have `requestId`
- ✅ Database fields are `snake_case`
- ✅ API response fields are `camelCase`
- ✅ All files are `kebab-case.js`
- ✅ All routes are `/api/v1/<kebab-case>`

---

## Output

Generate:
1. Complete file structure (copy-paste ready)
2. All code files with full implementations
3. package.json with correct dependencies
4. .env.example with all variables
5. docker-compose.yml
6. Quick start guide

Keep code consistent, follow 21 rules, use TypeScript-ready patterns.
