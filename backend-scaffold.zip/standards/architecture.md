# 🏛️ 4-Layer Architecture Pattern

**Route → Controller → Service → Repository**

---

## 📐 Layer Responsibilities

```
CLIENT REQUEST
     ↓
[ROUTE] ← Validation + Middleware
     ↓
[CONTROLLER] ← Orchestration + HTTP Response
     ↓
[SERVICE] ← Business Logic + Error Handling
     ↓
[REPOSITORY] ← Database Access Only
     ↓
DATABASE
```

---

## 1️⃣ Route Layer

**File:** `<module>.route.js`

**Responsibility:**
- ✅ Define endpoints
- ✅ Attach validation middleware
- ✅ Attach auth middleware
- ✅ Call controller methods

**Rules:**
- ❌ ห้ามใส่ business logic
- ❌ ห้าม direct DB query
- ✅ ต้องเรียก middleware + controller เท่านั้น

**Example:**
```javascript
import express from 'express';
import { validate } from '../middleware/validate.js';
import { authenticate } from '../middleware/authenticate.js';
import * as productController from './products.controller.js';
import { createProductSchema, updateProductSchema } from './products.validator.js';

const router = express.Router();

// List
router.get('/', authenticate, productController.listProducts);

// Detail
router.get('/:id', authenticate, productController.getProduct);

// Create
router.post('/', authenticate, validate(createProductSchema), productController.createProduct);

// Update
router.put('/:id', authenticate, validate(updateProductSchema), productController.updateProduct);

// Delete
router.delete('/:id', authenticate, productController.deleteProduct);

export default router;
```

---

## 2️⃣ Controller Layer

**File:** `<module>.controller.js`

**Responsibility:**
- ✅ Orchestrate service calls
- ✅ Format response
- ✅ Handle HTTP concerns (status code, headers)
- ✅ Pass error to next(err)

**Rules:**
- ❌ ห้าม DB query โดยตรง
- ❌ ห้าม business logic
- ✅ ต้องเรียก service เท่านั้น
- ✅ ห้าม res.json() เอง - ต้อง next(err)

**Example:**
```javascript
import * as productService from './products.service.js';
import { AppError } from '../../utils/app-error.js';

export async function listProducts(req, res, next) {
  try {
    const { page = 1, limit = 10 } = req.query;
    const userContext = req.user;
    
    const result = await productService.listProducts(
      { page: parseInt(page), limit: parseInt(limit) },
      userContext
    );
    
    if (!result.success) {
      return next(new AppError(400, result.code, result.message));
    }
    
    return res.json({
      success: true,
      code: 'SUCCESS',
      message: null,
      data: result.data,
      pagination: result.pagination,
      requestId: req.id,
    });
  } catch (err) {
    next(err);
  }
}

export async function createProduct(req, res, next) {
  try {
    const { body: data } = req;
    const userContext = req.user;
    
    const result = await productService.createProduct(data, userContext);
    
    if (!result.success) {
      return next(new AppError(400, result.code, result.message));
    }
    
    return res.status(201).json({
      success: true,
      code: 'SUCCESS',
      message: null,
      data: result.data,
      requestId: req.id,
    });
  } catch (err) {
    next(err);
  }
}
```

---

## 3️⃣ Service Layer

**File:** `<module>.service.js`

**Responsibility:**
- ✅ Business logic
- ✅ Validation
- ✅ Call repository methods
- ✅ Coordinate multiple repos
- ✅ Error handling

**Rules:**
- ❌ ห้าม DB query โดยตรง
- ✅ ต้องเรียก repository เท่านั้น
- ✅ ต้องให้ error message ชัดเจน
- ✅ ต้อง return `{ success, code, message, data }`

**Example:**
```javascript
import * as productRepository from './products.repository.js';

export async function createProduct(data, userContext) {
  try {
    // Validation (business rules)
    if (data.quantity < 0) {
      return {
        success: false,
        code: 'INVALID_PARAM',
        message: 'Quantity must be positive',
      };
    }
    
    // Check duplicate
    const existing = await productRepository.findByCode(
      data.product_code,
      userContext
    );
    
    if (existing) {
      return {
        success: false,
        code: 'CONFLICT',
        message: 'Product code already exists',
      };
    }
    
    // Create via repository
    const createdProduct = await productRepository.create(data, userContext);
    
    return {
      success: true,
      code: 'SUCCESS',
      message: null,
      data: createdProduct,
    };
  } catch (error) {
    throw error;
  }
}
```

---

## 4️⃣ Repository Layer

**File:** `<module>.repository.js`

**Responsibility:**
- ✅ Database queries only
- ✅ Tenant filtering
- ✅ Optimistic locking checks
- ✅ Transaction coordination
- ✅ Return raw/serialized data

**Rules:**
- ❌ ห้าม business logic
- ❌ ห้ามเรียก service
- ✅ ต้องรวม tenantFilter เสมอ
- ✅ ต้องเช็ค upd_date ใน update/delete
- ✅ ต้องใช้ transaction

**Example:**
```javascript
import { ObjectId, Decimal128 } from 'mongodb';
import { getDatabase } from '../../config/database.js';
import { serializeDoc } from '../../utils/format.js';

function tenantFilter(userContext) {
  return {
    ou_id: new ObjectId(userContext.ou_id),
    branch_id: new ObjectId(userContext.branch_id),
    is_deleted: false,
  };
}

export async function findByCode(code, userContext) {
  const db = getDatabase();
  const product = await db.collection('products').findOne({
    ...tenantFilter(userContext),
    product_code: code,
  });
  
  return product ? { id: product._id.toString(), ...serializeDoc(product) } : null;
}

export async function create(data, userContext, session) {
  const db = getDatabase();
  const now = new Date();
  
  const createPayload = {
    ...data,
    price: Decimal128.fromString(String(data.price)),
    ou_id: new ObjectId(userContext.ou_id),
    branch_id: new ObjectId(userContext.branch_id),
    is_deleted: false,
    cr_by: userContext.username,
    cr_date: now,
    cr_prog: '/api/v1/products',
    upd_by: userContext.username,
    upd_date: now,
    upd_prog: '/api/v1/products',
  };
  
  const result = await db.collection('products').insertOne(createPayload, { session });
  
  return {
    id: result.insertedId.toString(),
    ...serializeDoc(createPayload),
  };
}

export async function update(id, data, userContext, currentUpdDate, session) {
  const db = getDatabase();
  const now = new Date();
  
  // Optimistic locking check
  const filter = {
    _id: new ObjectId(id),
    ...tenantFilter(userContext),
    upd_date: currentUpdDate,
  };
  
  const oldDoc = await db.collection('products').findOne(filter, { session });
  if (!oldDoc) {
    throw new Error('Data not found or already modified');
  }
  
  const updatePayload = {
    ...data,
    price: Decimal128.fromString(String(data.price)),
    upd_by: userContext.username,
    upd_date: now,
    upd_prog: '/api/v1/products',
  };
  
  await db.collection('products').updateOne(filter, { $set: updatePayload }, { session });
  
  return {
    id: oldDoc._id.toString(),
    ...serializeDoc({ ...oldDoc, ...updatePayload }),
  };
}
```

---

## 🔄 Complete Flow Example

### **Request: Create Product**
```
POST /api/v1/products
{
  "product_name": "Laptop",
  "product_code": "PROD-001",
  "price": "25000.00",
  "quantity": 50
}
```

### **Flow:**
```
1. ROUTE
   - validate(createProductSchema) ✓
   - authenticate ✓
   - Call productController.createProduct()

2. CONTROLLER
   - Get validated data: req.body
   - Get user context: req.user
   - Call productService.createProduct(data, userContext)
   - Handle response + error

3. SERVICE
   - Validate business rules (quantity > 0)
   - Check duplicate via productRepository.findByCode()
   - Call productRepository.create(data, userContext)
   - Return { success, code, data }

4. REPOSITORY
   - Start transaction
   - Build tenantFilter
   - Insert document with audit fields
   - Insert audit log
   - Commit transaction
   - Return serialized document

5. RESPONSE
   {
     "success": true,
     "code": "SUCCESS",
     "data": { "id": "...", "product_name": "...", "price": "25000.00" }
   }
```

---

## 📁 Folder Structure

```
src/modules/products/
├── products.route.js          ← Route definitions
├── products.controller.js      ← HTTP orchestration
├── products.service.js         ← Business logic
├── products.repository.js      ← DB access
└── products.validator.js       ← Joi schemas
```

---

## ✅ Checklist per Layer

### **Route Checklist**
- [ ] ต้องมี authenticate middleware
- [ ] ต้องมี validate middleware (except GET list)
- [ ] ต้องเรียก controller method
- [ ] ไม่มี business logic

### **Controller Checklist**
- [ ] ต้องเรียก service เท่านั้น
- [ ] ต้องส่ง error ด้วย next(err)
- [ ] ต้องส่ง response ที่สมบูรณ์
- [ ] ต้องมี requestId ใน response

### **Service Checklist**
- [ ] ต้องมี business logic validation
- [ ] ต้องเรียก repository เท่านั้น
- [ ] ต้องส่ง { success, code, message, data }
- [ ] ต้องมี error handling

### **Repository Checklist**
- [ ] ต้องมี tenantFilter
- [ ] ต้องเช็ค upd_date ใน update/delete
- [ ] ต้องใช้ transaction
- [ ] ต้องส่ง serialized data
- [ ] ไม่มี business logic

---

**Status:** Ready to Use ✅  
**Version:** 1.0  
**Last Updated:** 2026-05-15
