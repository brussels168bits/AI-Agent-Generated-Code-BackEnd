# 📡 API Response & Error Format Standard

---

## ✅ Success Response

### **Detail Response (200 OK)**
```json
{
  "success": true,
  "code": "SUCCESS",
  "message": null,
  "data": {
    "id": "507f1f77bcf86cd799439011",
    "product_name": "Laptop",
    "product_code": "PROD-001",
    "price": "25000.00",
    "quantity": 50,
    "status": "active",
    "createdAt": "2026-05-15T10:30:00Z",
    "updatedAt": "2026-05-15T14:30:00Z"
  },
  "requestId": "550e8400-e29b-41d4-a716-446655440000"
}
```

### **List Response (200 OK)**
```json
{
  "success": true,
  "code": "SUCCESS",
  "message": null,
  "data": [
    {
      "id": "507f1f77bcf86cd799439011",
      "product_name": "Laptop",
      "price": "25000.00"
    },
    {
      "id": "507f1f77bcf86cd799439012",
      "product_name": "Mouse",
      "price": "500.00"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 250,
    "totalPages": 25
  },
  "requestId": "550e8400-e29b-41d4-a716-446655440000"
}
```

### **Create Response (201 Created)**
```json
{
  "success": true,
  "code": "SUCCESS",
  "message": null,
  "data": {
    "id": "507f1f77bcf86cd799439011",
    "product_name": "Laptop",
    "product_code": "PROD-001",
    "price": "25000.00",
    "createdAt": "2026-05-15T10:30:00Z"
  },
  "requestId": "550e8400-e29b-41d4-a716-446655440000"
}
```

### **Delete Response (200 OK)**
```json
{
  "success": true,
  "code": "SUCCESS",
  "message": null,
  "data": null,
  "requestId": "550e8400-e29b-41d4-a716-446655440000"
}
```

---

## ❌ Error Responses

### **Bad Request (400)**
```json
{
  "success": false,
  "code": "INVALID_PARAM",
  "message": "product_name is required",
  "data": null,
  "requestId": "550e8400-e29b-41d4-a716-446655440000"
}
```

### **Unauthorized (401)**
```json
{
  "success": false,
  "code": "UNAUTHORIZED",
  "message": "Invalid credentials",
  "data": null,
  "requestId": "550e8400-e29b-41d4-a716-446655440000"
}
```

### **Token Expired (401)**
```json
{
  "success": false,
  "code": "TOKEN_EXPIRED",
  "message": "Your session has expired. Please login again.",
  "data": null,
  "requestId": "550e8400-e29b-41d4-a716-446655440000"
}
```

### **Forbidden (403)**
```json
{
  "success": false,
  "code": "MISSING_AUTHORIZATION",
  "message": "You do not have permission to access this resource",
  "data": null,
  "requestId": "550e8400-e29b-41d4-a716-446655440000"
}
```

### **Not Found (404)**
```json
{
  "success": false,
  "code": "DATA_NOT_FOUND",
  "message": "Product not found",
  "data": null,
  "requestId": "550e8400-e29b-41d4-a716-446655440000"
}
```

### **Conflict (409) - Already Exists**
```json
{
  "success": false,
  "code": "CONFLICT",
  "message": "Product code PROD-001 already exists",
  "data": null,
  "requestId": "550e8400-e29b-41d4-a716-446655440000"
}
```

### **Conflict (409) - Optimistic Locking Failed**
```json
{
  "success": false,
  "code": "CONFLICT",
  "message": "Data has been modified by another user. Please refresh and try again.",
  "data": null,
  "requestId": "550e8400-e29b-41d4-a716-446655440000"
}
```

### **Too Many Requests (429)**
```json
{
  "success": false,
  "code": "TOO_MANY_REQUESTS",
  "message": "Too many requests. Please try again later.",
  "data": null,
  "requestId": "550e8400-e29b-41d4-a716-446655440000"
}
```

### **Server Error (500)**
```json
{
  "success": false,
  "code": "INTERNAL_ERROR",
  "message": "An unexpected error occurred",
  "data": null,
  "requestId": "550e8400-e29b-41d4-a716-446655440000"
}
```

---

## 📋 Response Structure

### **Fields**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `success` | Boolean | ✅ | Always present: `true` or `false` |
| `code` | String | ✅ | Error/success code (see codes table below) |
| `message` | String \| null | ✅ | User-friendly message; `null` if success |
| `data` | Object \| Array \| null | ✅ | Response data; `null` if error |
| `pagination` | Object \| undefined | ❌ | Only for list responses |
| `requestId` | String | ✅ | Unique request ID for tracking |

### **Response Codes**

| HTTP | Code | Usage |
|------|------|-------|
| 200 | `SUCCESS` | Successful operation |
| 200 | `DATA_NOT_FOUND` | Not found (but treated as success in list) |
| 201 | `SUCCESS` | Resource created |
| 400 | `INVALID_PARAM` | Bad request body |
| 400 | `INVALID_HEADER` | Bad request header |
| 401 | `UNAUTHORIZED` | Invalid credentials |
| 401 | `TOKEN_EXPIRED` | JWT token expired |
| 403 | `MISSING_AUTHORIZATION` | No permission |
| 403 | `MISSING_ORIGIN` | CORS origin not allowed |
| 403 | `MISSING_CONTENT_TYPE` | Missing Content-Type header |
| 404 | `DATA_NOT_FOUND` | Resource not found |
| 409 | `CONFLICT` | Duplicate or optimistic lock failure |
| 429 | `TOO_MANY_REQUESTS` | Rate limit exceeded |
| 500 | `INTERNAL_ERROR` | Server error |

---

## 🔢 Pagination

### **Request**
```
GET /api/v1/products?page=2&limit=20
```

### **Response**
```json
{
  "success": true,
  "code": "SUCCESS",
  "data": [...],
  "pagination": {
    "page": 2,
    "limit": 20,
    "total": 250,
    "totalPages": 13
  }
}
```

### **Rules**
- Default: `page=1`, `limit=10`
- Max limit: `100` (auto-capped)
- Out of range: return empty array
- Calculation: `totalPages = Math.ceil(total / limit)`

---

## 📝 Data Type Rules

### **DateTime**
```json
{
  "createdAt": "2026-05-15T10:30:00Z",
  "updatedAt": "2026-05-15T14:30:00Z"
}
```
- Always ISO 8601 format
- Always UTC timezone
- Never include local timezone

### **Money/Currency**
```json
{
  "price": "25000.00",
  "total": "1250.50"
}
```
- Always as String (not Number)
- Preserve decimal places
- Use 2-4 decimal places depending on currency

### **ID/Reference**
```json
{
  "id": "507f1f77bcf86cd799439011",
  "productId": "507f1f77bcf86cd799439012",
  "categoryId": "507f1f77bcf86cd799439013"
}
```
- Always as String (not ObjectId)
- Use camelCase in API responses
- Store as ObjectId in database

### **Boolean**
```json
{
  "isActive": true,
  "isDeleted": false
}
```
- Use camelCase
- Never null (default to `false`)

### **Null Handling**
```json
{
  "data": {
    "id": "507f1f77bcf86cd799439011",
    "middleName": null,
    "deletedDate": null
  }
}
```
- Include `null` values
- Don't omit keys with null values
- Use `null` not `undefined`

---

## 🛠️ Implementation Examples

### **Controller Success Response**
```javascript
export async function getProduct(req, res, next) {
  try {
    const result = await productService.getProduct(req.params.id, req.user);
    
    if (!result.success) {
      return next(new AppError(404, result.code, result.message));
    }
    
    return res.json({
      success: true,
      code: 'SUCCESS',
      message: null,
      data: result.data,
      requestId: req.id,
    });
  } catch (err) {
    next(err);
  }
}
```

### **Controller List Response**
```javascript
export async function listProducts(req, res, next) {
  try {
    const { page, limit } = req.query;
    const result = await productService.listProducts(
      { page, limit },
      req.user
    );
    
    return res.json({
      success: true,
      code: 'SUCCESS',
      message: null,
      data: result.data,
      pagination: result.pagination,
      requestId: req.id,
    });
  } catch (err) {
    next(err);
  }
}
```

### **Global Error Handler**
```javascript
export function errorHandler(err, req, res, next) {
  let statusCode = 500;
  let code = 'INTERNAL_ERROR';
  let message = 'An unexpected error occurred';
  
  if (err instanceof AppError) {
    statusCode = err.statusCode;
    code = err.code;
    message = err.message;
  }
  
  return res.status(statusCode).json({
    success: false,
    code,
    message,
    data: null,
    requestId: req.id,
  });
}
```

---

## ✅ Response Checklist

- [ ] `success` field present
- [ ] `code` field present
- [ ] `message` field present (null for success)
- [ ] `data` field present (null for errors)
- [ ] `requestId` field present
- [ ] DateTime as ISO 8601 UTC string
- [ ] Money as string
- [ ] ID as string
- [ ] Boolean never null
- [ ] Null values included (not omitted)
- [ ] HTTP status code correct
- [ ] Pagination included for lists

---

**Status:** Ready to Use ✅  
**Version:** 1.0  
**Last Updated:** 2026-05-15
