# 🏷️ Naming Conventions Standard

---

## 📋 Quick Reference

| Category | Format | Example |
|----------|--------|---------|
| Variable | `camelCase` | `productName`, `userId`, `isActive` |
| Function | `camelCase` | `getProduct`, `createUserAccount`, `validateEmail` |
| Class | `PascalCase` | `ProductService`, `UserRepository`, `AuthController` |
| Interface | `PascalCase` | `IProduct`, `ICreateProductRequest`, `IApiResponse` |
| Constants | `UPPER_SNAKE_CASE` | `MAX_PAGE_LIMIT`, `DEFAULT_TIMEOUT_MS`, `API_VERSION` |
| **Database Field** | **`snake_case`** | **`product_name`, `user_id`, `is_active`** |
| **Database Collection** | **`snake_case`** | **`products`, `user_accounts`, `bank_branches`** |
| Folder | `kebab-case` | `user-accounts`, `product-management`, `auth-service` |
| File (JS) | `kebab-case.js` | `products.route.js`, `user.service.js` |
| **URL/Route** | **`kebab-case`** | **`/api/v1/user-accounts`, `/api/v1/bank-branches`** |

---

## 📝 Detailed Conventions

### **1. Variable Names**

```javascript
// ✅ CORRECT - camelCase
const productName = 'Laptop';
const userId = '507f1f77bcf86cd799439011';
const isActive = true;
const totalAmount = 1250.50;
const createdDate = new Date();

// ❌ WRONG
const product_name = 'Laptop';     // snake_case
const PRODUCT_NAME = 'Laptop';     // UPPER_CASE
const ProductName = 'Laptop';      // PascalCase
const pName = 'Laptop';            // abbreviation
```

### **2. Function Names**

```javascript
// ✅ CORRECT - camelCase verb-noun
function getProduct(id) { }
function createUserAccount(data) { }
function updateProductPrice(id, newPrice) { }
function deleteUser(id) { }
function validateEmail(email) { }
function calculateTotalAmount(items) { }
function formatDateTime(date) { }
function serializeDocument(doc) { }

// ❌ WRONG
function GET_PRODUCT(id) { }           // UPPER_CASE
function get_product(id) { }           // snake_case
function GetProduct(id) { }            // PascalCase
function get(id) { }                   // too short
function getProductByIdAndFilterByName() { }  // too long
```

### **3. Class / Constructor Names**

```javascript
// ✅ CORRECT - PascalCase
class ProductService { }
class UserRepository { }
class AuthController { }
class DatabaseConnection { }
class ValidationError extends Error { }
class RateLimitMiddleware { }

// ❌ WRONG
class productService { }               // camelCase
class product_service { }              // snake_case
class service { }                      // too generic
class ProductServiceAndControllerClass { }  // too long
```

### **4. Interface / Type Names**

```javascript
// ✅ CORRECT - PascalCase (with I prefix optional)
interface IProduct {
  id: string;
  productName: string;
}

interface CreateProductRequest {
  productName: string;
  price: string;
}

interface ApiResponse<T> {
  success: boolean;
  code: string;
  data: T;
}

// ❌ WRONG
interface iProduct { }              // lowercase i
interface product { }               // no prefix
interface i_product { }             // snake_case
```

### **5. Constants**

```javascript
// ✅ CORRECT - UPPER_SNAKE_CASE
const MAX_PAGE_LIMIT = 100;
const DEFAULT_PAGE_SIZE = 10;
const REQUEST_TIMEOUT_MS = 30000;
const API_VERSION = 'v1';
const JWT_EXPIRATION_DAYS = 7;
const MIN_PASSWORD_LENGTH = 8;

// ❌ WRONG
const maxPageLimit = 100;              // camelCase
const MAX_PAGE_limit = 100;            // mixed
const max_page_limit = 100;            // snake_case
const MAXPAGELIMIT = 100;              // no underscore separation
```

### **6. Database Fields (CRITICAL)**

```javascript
// ✅ CORRECT - snake_case
{
  _id: ObjectId,
  ou_id: ObjectId,
  branch_id: ObjectId,
  product_name: String,
  product_code: String,
  is_deleted: Boolean,
  is_active: Boolean,
  cr_date: Date,
  upd_date: Date,
  cr_by: String,
  upd_by: String,
  cr_prog: String,
  upd_prog: String,
  deleted_by: String,
  deleted_date: Date,
  deleted_prog: String,
}

// ❌ WRONG
{
  _id: ObjectId,
  OUId: ObjectId,             // PascalCase
  branchId: ObjectId,         // camelCase
  productName: String,        // camelCase
  IsDeleted: Boolean,         // PascalCase
  cr-date: Date,              // kebab-case (invalid in JS)
}
```

### **7. API Response Fields**

API responses use **camelCase** (convert from DB snake_case):

```javascript
// Database (snake_case)
{
  _id: ObjectId,
  product_name: String,
  ou_id: ObjectId,
  is_active: Boolean,
  cr_date: Date,
}

// API Response (camelCase)
{
  id: String,
  productName: String,
  ouId: String,
  isActive: Boolean,
  createdAt: String,
}
```

### **8. File Names**

```javascript
// ✅ CORRECT - kebab-case
// Routes
products.route.js
user-accounts.route.js
auth.route.js

// Controllers
products.controller.js
user-accounts.controller.js

// Services
products.service.js
user-accounts.service.js

// Repositories
products.repository.js
user-accounts.repository.js

// Validators
products.validator.js
user-accounts.validator.js

// Utilities
app-error.js
format.js
logger.js
database.js

// ❌ WRONG
ProductsRoute.js            // PascalCase
products_route.js           // snake_case
productsRoute.js            // camelCase
```

### **9. Folder Names**

```javascript
// ✅ CORRECT - kebab-case
src/
  modules/
    products/
    user-accounts/
    bank-branches/
    auth/
  middleware/
  utils/
  config/

// ❌ WRONG
modules/Products/           // PascalCase
modules/user_accounts/      // snake_case
modules/UserAccounts/       // PascalCase
```

### **10. Route URLs**

```javascript
// ✅ CORRECT - kebab-case, plural resource name
GET    /api/v1/products
POST   /api/v1/products
GET    /api/v1/products/:id
PUT    /api/v1/products/:id
DELETE /api/v1/products/:id

GET    /api/v1/user-accounts
POST   /api/v1/user-accounts
PUT    /api/v1/user-accounts/:id

GET    /api/v1/bank-branches
PUT    /api/v1/bank-branches/:id

// ❌ WRONG
/api/v1/product              // singular
/api/v1/Products             // PascalCase
/api/v1/user_accounts        // snake_case
/api/v1/get_products         // verb in URL
/api/v1/create_product       // verb in URL
```

---

## 🔄 Conversion Examples

### **Database → JavaScript → API**

```javascript
// Database (snake_case)
{
  _id: ObjectId('507f1f77bcf86cd799439011'),
  ou_id: ObjectId('507f1f77bcf86cd799439012'),
  product_code: 'PROD-001',
  product_name: 'Laptop',
  price: Decimal128('25000.00'),
  is_active: true,
  is_deleted: false,
  cr_date: Date('2026-05-15T10:30:00Z'),
}

// JavaScript (camelCase in code)
const product = {
  id: doc._id.toString(),
  ouId: doc.ou_id.toString(),
  productCode: doc.product_code,
  productName: doc.product_name,
  price: doc.price.toString(),
  isActive: doc.is_active,
  isDeleted: doc.is_deleted,
  createdAt: doc.cr_date.toISOString(),
};

// API Response (camelCase)
{
  "success": true,
  "data": {
    "id": "507f1f77bcf86cd799439011",
    "ouId": "507f1f77bcf86cd799439012",
    "productCode": "PROD-001",
    "productName": "Laptop",
    "price": "25000.00",
    "isActive": true,
    "isDeleted": false,
    "createdAt": "2026-05-15T10:30:00Z"
  }
}
```

---

## 🎯 Naming for Specific Patterns

### **Repository Methods**

```javascript
// ✅ CORRECT naming
class ProductRepository {
  async findOne(id, userContext) { }
  async findMany(filter) { }
  async findByCode(code, userContext) { }
  async create(data, userContext, session) { }
  async update(id, data, userContext, updDate, session) { }
  async delete(id, userContext, session) { }
  async countDocuments(filter) { }
}
```

### **Service Methods**

```javascript
// ✅ CORRECT naming
class ProductService {
  async getProduct(id, userContext) { }
  async listProducts(pagination, userContext) { }
  async createProduct(data, userContext) { }
  async updateProduct(id, data, userContext) { }
  async deleteProduct(id, userContext) { }
}
```

### **Validator Schema Names**

```javascript
// ✅ CORRECT naming
const createProductSchema = Joi.object({ ... });
const updateProductSchema = Joi.object({ ... });
const listProductsQuerySchema = Joi.object({ ... });
const productIdSchema = Joi.object({ ... });
```

### **Environment Variables**

```javascript
// ✅ CORRECT - UPPER_SNAKE_CASE
DATABASE_URL
DATABASE_NAME
JWT_SECRET
JWT_EXPIRATION_DAYS
PORT
NODE_ENV
API_VERSION
LOG_LEVEL
REDIS_URL
STRIPE_API_KEY
```

---

## ✅ Checklist

- [ ] Variables: `camelCase`
- [ ] Functions: `camelCase`
- [ ] Classes: `PascalCase`
- [ ] Constants: `UPPER_SNAKE_CASE`
- [ ] Database fields: `snake_case`
- [ ] Files: `kebab-case.js`
- [ ] Folders: `kebab-case`
- [ ] Routes: `kebab-case`
- [ ] API response fields: `camelCase`
- [ ] Environment vars: `UPPER_SNAKE_CASE`

---

**Status:** Ready to Use ✅  
**Version:** 1.0  
**Last Updated:** 2026-05-15
