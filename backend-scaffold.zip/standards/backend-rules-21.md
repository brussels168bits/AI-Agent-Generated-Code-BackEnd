# 🏗️ Backend Rules 21 — Master Reference

**Complete Node.js + MongoDB Backend Standards**

---

## 🔧 Stack

| Component | Version | Rule |
| --- | --- | --- |
| Runtime | Node.js 24.11 LTS | ESM `import`/`export` เท่านั้น |
| Database | MongoDB ≥8.0 | Replica Set, ห้ามใช้ Mongoose |
| Logger | `pino` ^9.2.0 | ห้าม `console.log` |
| Validator | `joi` ^17.13.0 | ชื่อไฟล์ `<module>.validator.js` |
| Auth | `jsonwebtoken` ^9.0.2 | Bearer Token, decode ใน Middleware เท่านั้น |
| Date | `dayjs` + utc plugin | เก็บเป็น UTC เสมอ, ส่ง ISO 8601 String |

---

## 🏛️ Architecture — 4 Layers

| Layer | กฎ |
| --- | --- |
| **Route** | ห้ามใส่ Logic — เรียก Middleware + Controller เท่านั้น |
| **Controller** | Orchestrate + Response — ห้าม DB Query |
| **Service** | Business Logic — ห้าม DB Query โดยตรง |
| **Repository** | DB Access — ห้ามเรียก Service อื่น |

**File naming:** `<module>.[route|validator|controller|service|repository].js`  
**Folder:** `src/modules/<module>/`

---

## 📝 Naming Conventions

| ประเภท | รูปแบบ | ตัวอย่าง |
| --- | --- | --- |
| Variable / Function | `camelCase` | `findProducts`, `getUserById` |
| Class / Interface | `PascalCase` | `ProductService`, `UserRepository` |
| **DB Field / JSON API** | **`snake_case`** | `product_name`, `ou_id`, `cr_date` |
| Constants | `UPPER_SNAKE_CASE` | `MAX_LIMIT`, `DEFAULT_PAGE_SIZE` |
| Folder / File / URL | `kebab-case` | `bank-accounts`, `products.route.js` |

---

## 🔐 API Response Structure

### **Standard Format**
```json
{
  "success": true,
  "code": "SUCCESS",
  "message": null,
  "data": { ... },
  "requestId": "uuid"
}
```

### **List Response**
```json
{
  "success": true,
  "code": "SUCCESS",
  "message": null,
  "data": [...],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 150,
    "totalPages": 15
  },
  "requestId": "uuid"
}
```

### **Error Response**
```json
{
  "success": false,
  "code": "INVALID_PARAM",
  "message": "Field validation failed",
  "data": null,
  "requestId": "uuid"
}
```

### **HTTP Status → Code Mapping**

| HTTP | Code |
| --- | --- |
| 200 | `SUCCESS` / `DATA_NOT_FOUND` |
| 400 | `INVALID_PARAM` / `INVALID_HEADER` |
| 401 | `UNAUTHORIZED` / `TOKEN_EXPIRED` |
| 403 | `MISSING_AUTHORIZATION` / `MISSING_ORIGIN` / `MISSING_CONTENT_TYPE` |
| 409 | `CONFLICT` |
| 429 | `TOO_MANY_REQUESTS` |
| 500 | `INTERNAL_ERROR` |

**Data Types:**
- DateTime → ISO 8601 String
- Money → String (Decimal128 in DB)
- ID → String (ObjectId in DB)
- `null` ไม่ตัด key

---

## 🔗 API Rules

- **URL:** `/api/v1/<plural-kebab-resource>` (e.g., `/api/v1/bank-accounts`)
- **Pagination:** default `page=1`, `limit=10` (max 100, auto-correct)
- **Rate Limit:** General 100 req/min, Auth 5–10 req/15min (`skipSuccessfulRequests: true`)
- **Health:** ทุก Service ต้องมี `GET /health`

---

## ⭐ CRITICAL Patterns (ห้ามลืม)

### **Rule 1️⃣: Tenant Isolation — ทุก Query ต้องขึ้นต้นด้วย ou_id + branch_id**

```javascript
// ✅ CORRECT
const filter = {
  ou_id: new ObjectId(userContext.ou_id),
  branch_id: new ObjectId(userContext.branch_id),
  is_deleted: false,
  ...otherConditions,
};
const doc = await db.collection('products').findOne(filter);

// ❌ WRONG
const doc = await db.collection('products').findOne({ product_id: id });
```

**Helper function:**
```javascript
function tenantFilter(userContext) {
  return {
    ou_id: new ObjectId(userContext.ou_id),
    branch_id: new ObjectId(userContext.branch_id),
    is_deleted: false,
  };
}
```

---

### **Rule 2️⃣: Optimistic Locking — ทุก UPDATE/DELETE เช็ค upd_date เดิม**

```javascript
const filter = {
  _id: new ObjectId(id),
  ...tenantFilter(userContext),
  upd_date: original_upd_date,  // ← Version check
};

const oldDoc = await db.collection('products').findOne(filter, { session });
if (!oldDoc) {
  throw new AppError(409, 'CONFLICT', 'Data not found or already modified');
}

// Update
const updateResult = await db.collection('products').updateOne(
  filter,
  { $set: { ...updatePayload } },
  { session }
);
```

---

### **Rule 3️⃣: Audit Fields — CREATE ตั้ง cr_ และ upd_ พร้อมกัน**

```javascript
const now = new Date();
const createPayload = {
  ...data,
  ou_id: new ObjectId(userContext.ou_id),
  branch_id: new ObjectId(userContext.branch_id),
  is_deleted: false,
  // Create fields
  cr_by: userContext.username,
  cr_date: now,
  cr_prog: '/api/v1/products',
  // Update fields (set together)
  upd_by: userContext.username,
  upd_date: now,
  upd_prog: '/api/v1/products',
};

await db.collection('products').insertOne(createPayload, { session });

// UPDATE — ตั้งเฉพาะชุด upd_
const updatePayload = {
  ...data,
  upd_by: userContext.username,
  upd_date: new Date(),
  upd_prog: '/api/v1/products',
};

await db.collection('products').updateOne(filter, { $set: updatePayload }, { session });
```

---

### **Rule 4️⃣: Soft Delete — 4 fields บังคับ**

```javascript
// Schema fields (required)
{
  is_deleted: false,
  deleted_by: null,
  deleted_date: null,
  deleted_prog: null,
}

// Delete operation
const now = new Date();
const deletePayload = {
  is_deleted: true,
  deleted_by: userContext.username,
  deleted_date: now,
  deleted_prog: '/api/v1/products',
  // Also update upd_ fields
  upd_by: userContext.username,
  upd_date: now,
  upd_prog: '/api/v1/products',
};

await db.collection('products').updateOne(filter, { $set: deletePayload }, { session });
```

---

### **Rule 5️⃣: Log Format — snapshot_data + changed_fields**

```javascript
// INSERT log
{
  action: 'INSERT',
  changed_fields: null,
  snapshot_data: { old: null, new: payload },
  ref_id: new ObjectId(createdDocId),
  ou_id: new ObjectId(userContext.ou_id),
  branch_id: new ObjectId(userContext.branch_id),
  cr_by: userContext.username,
  cr_date: new Date(),
  cr_prog: '/api/v1/products',
}

// UPDATE log
{
  action: 'UPDATE',
  changed_fields: {
    product_name: { old: oldDoc.product_name, new: newValue },
    price: { old: oldDoc.price, new: newValue },
  },
  snapshot_data: { old: oldDoc, new: { ...oldDoc, ...updatePayload } },
  ref_id: oldDoc._id,
  ou_id: oldDoc.ou_id,
  branch_id: oldDoc.branch_id,
  cr_by: userContext.username,
  cr_date: new Date(),
  cr_prog: '/api/v1/products',
}

// DELETE log
{
  action: 'DELETE',
  changed_fields: null,
  snapshot_data: { old: oldDoc, new: null },
  ref_id: oldDoc._id,
  ou_id: oldDoc.ou_id,
  branch_id: oldDoc.branch_id,
  cr_by: userContext.username,
  cr_date: new Date(),
  cr_prog: '/api/v1/products',
}
```

---

### **Rule 6️⃣: Transaction Shell — Create/Update/Delete + Log**

```javascript
const client = getClient();
const session = client.startSession();

try {
  let result;
  await session.withTransaction(async () => {
    const db = getDatabase();
    const now = new Date();
    
    // 1. Main operation (insert/update/delete)
    const operationResult = await db.collection('products').insertOne(payload, { session });
    
    // 2. Insert audit log immediately after
    await db.collection('product_logs').insertOne({
      action: 'INSERT',
      ref_id: operationResult.insertedId,
      snapshot_data: { old: null, new: payload },
      ou_id: payload.ou_id,
      branch_id: payload.branch_id,
      cr_by: userContext.username,
      cr_date: now,
      cr_prog: '/api/v1/products',
    }, { session });
    
    result = operationResult;
  });
  
  return result;
} catch (error) {
  throw error;
} finally {
  await session.endSession();
}
```

---

### **Rule 7️⃣: serializeDoc — แปลง Decimal128 + Date ก่อนส่ง Response**

```javascript
import { Decimal128 } from 'mongodb';

function serializeDoc(doc) {
  if (!doc) return null;
  
  const serialized = { ...doc };
  
  // Convert Decimal128 to string
  Object.keys(serialized).forEach(key => {
    if (serialized[key] instanceof Decimal128) {
      serialized[key] = serialized[key].toString();
    }
    // Date stays as ISO string (MongoDB driver handles this)
  });
  
  return serialized;
}

// LIST
const products = await db.collection('products').find(filter).toArray();
const serialized = products.map((d) => ({
  id: d._id.toString(),
  ...serializeDoc(d),
}));

// DETAIL
const product = await db.collection('products').findOne(filter);
const detail = product ? { id: product._id.toString(), ...serializeDoc(product) } : null;
```

---

### **Rule 8️⃣: AppError — throw pattern**

```javascript
import { AppError } from '../../utils/app-error.js';

// Examples
throw new AppError(400, 'INVALID_PARAM', 'Email is required');
throw new AppError(409, 'CONFLICT', 'Data not found or already modified');
throw new AppError(404, 'DATA_NOT_FOUND', 'Product not found');
throw new AppError(401, 'UNAUTHORIZED', 'Invalid credentials');
throw new AppError(403, 'MISSING_AUTHORIZATION', 'You do not have permission');

// In controller — ห้าม res.json() เอง
try {
  const result = await productService.createProduct(data);
  res.status(201).json({
    success: true,
    code: 'SUCCESS',
    data: result,
  });
} catch (err) {
  next(err);  // ← Pass to error handler
}
```

---

### **Rule 9️⃣: Program Naming (cr_prog / upd_prog)**

```javascript
// API: ใช้ full path
cr_prog: '/api/v1/bank-accounts'
upd_prog: '/api/v1/bank-accounts'

// Cron/Scheduled Job: ใช้ kebab-case job name
cr_prog: 'calculate-commission'
upd_prog: 'process-invoices'

// Batch/Bulk Operation: ใช้ special naming
cr_prog: 'bulk-import-users'
upd_prog: 'batch-update-status'
```

---

### **Rule 🔟: Middleware Order ใน app.js (ห้ามสลับ)**

```javascript
// Order matters! ต้องเป็นลำดับนี้เสมอ
app.use(requestIdMiddleware);           // 1. Generate requestId
app.use(express.json());                 // 2. Parse JSON
app.use(express.urlencoded());          // 3. Parse URL encoded
app.set('trust proxy', 1);              // 4. Trust proxy (for rate limit)
app.use(rateLimitMiddleware);           // 5. Rate limit
app.use('/api/v1/auth', authRoutes);    // 6. Auth routes
app.use(authenticateMiddleware);        // 7. Auth check (JWT)
app.use('/api/v1', apiRoutes);          // 8. Protected routes
app.use((req, res) => res.status(404).json(...));  // 9. 404
app.use(errorHandlerMiddleware);        // 10. Error handler (LAST!)
```

---

## 💾 Database Standards

- **Collection/Field:** `snake_case` — `products`, `product_name`, `cr_date`
- **Index naming:** `idx_[fields]`, Unique: `uk_[fields]`, TTL: `ttl_[fields]`
- **ESR Index Order:** Equality → Sort → Range
- **Compound Index ต้องรวม:** `ou_id`, `branch_id`, `is_deleted`
- **Read Preference:** `primaryPreferred` (default) | `primary` (financial) | `secondary` (report)
- **Currency:** เก็บ `Decimal128` — ส่ง `String`
- **ID:** เก็บ `ObjectId` — ส่ง `String`

---

## ⚡ 21 Rules Quick Reference

| # | กฎ | รายละเอียด |
| --- | --- | --- |
| 1 | **Tenant Isolation** | ทุก Query ต้องมี `ou_id` + `branch_id` เป็นเงื่อนไขแรก |
| 2 | **Optimistic Locking** | ทุก Update/Delete ต้องเช็ค `upd_date` เดิม |
| 3 | **Audit Fields** | ทุก Create ต้องมี `cr_*` + `upd_*` / Update ต้องมี `upd_*` |
| 4 | **No Mongoose** | ใช้ `mongodb` native driver เท่านั้น |
| 5 | **No Hardcode** | URI, Credentials ต้องอ่านจาก ENV เสมอ |
| 6 | **Real HTTP Status** | ห้ามส่ง 200 แต่ code เป็น Error |
| 7 | **ISO 8601 DateTime** | ส่งวันที่เป็น UTC String เสมอ |
| 8 | **Money as String** | DB=`Decimal128`, API=`String` |
| 9 | **findOne for Detail** | ห้ามใช้ `find().toArray()[0]` |
| 10 | **ESR Index Order** | Equality → Sort → Range เสมอ |
| 11 | **Global Error Handler** | ทุก error ต้อง `next(err)` — ห้าม `res.json()` เองใน Controller |
| 12 | **Request ID** | ทุก Request ต้องมี `requestId` แนบใน Error Response และ Log |
| 13 | **Auth Middleware** | decode JWT ใน Middleware เท่านั้น — `req.user` ส่งต่อให้ Controller |
| 14 | **Soft Delete** | ใช้ `is_deleted: false` — ทุก Query ต้องกรอง `is_deleted` |
| 15 | **Transaction** | Create/Update/Delete + Log ต้องอยู่ใน Transaction เดียวกัน |
| 16 | **CRUD Pattern** | Route → Validator → Controller → Service → Repository |
| 17 | **Validate Middleware** | ใช้ `validate(schema)` ใน Route — ห้าม validate เองใน Controller |
| 18 | **Logger (Pino)** | `pino` เท่านั้น — `info` ปกติ / `error` exception / `debug` verbose |
| 19 | **Middleware Order** | requestId → body → proxy → rateLimit → routes → 404 → errorHandler |
| 20 | **Decimal128** | DB=`Decimal128` → ต้องแปลงเป็น `String` ก่อนส่ง Response |
| 21 | **ESM Only** | `import`/`export` เท่านั้น — ห้าม `require`/`module.exports` |

---

**Version:** 1.0  
**Last Updated:** 2026-05-15  
**Status:** Ready for Implementation ✅
