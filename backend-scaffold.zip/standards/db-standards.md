# 💾 MongoDB Database Standards

---

## 🔤 Naming Conventions

### **Collections**
```javascript
// ✅ CORRECT - snake_case
db.createCollection('products');
db.createCollection('product_categories');
db.createCollection('bank_accounts');

// ❌ WRONG
db.createCollection('Products');
db.createCollection('ProductCategories');
db.createCollection('bankAccounts');
```

### **Fields**
```javascript
// ✅ CORRECT - snake_case
{
  product_id: ObjectId,
  product_name: String,
  product_code: String,
  ou_id: ObjectId,
  branch_id: ObjectId,
  is_deleted: Boolean,
  cr_date: Date,
  upd_date: Date,
}

// ❌ WRONG
{
  productId: ObjectId,
  productName: String,
  OUId: ObjectId,
  isDeleted: Boolean,
}
```

---

## 🔑 Index Standards

### **Naming Convention**
```javascript
// Prefix: idx_      (regular index)
// Prefix: uk_       (unique index)
// Prefix: ttl_      (TTL index)

// Examples
{
  name: 'idx_ou_id_branch_id',      // Regular compound
  key: { ou_id: 1, branch_id: 1 },
}

{
  name: 'uk_product_code_ou_id',    // Unique compound
  key: { product_code: 1, ou_id: 1 },
  unique: true,
}

{
  name: 'ttl_session_created_at',   // TTL index
  key: { created_at: 1 },
  expireAfterSeconds: 3600,
}
```

### **ESR Index Order (CRITICAL)**

**E**quality → **S**ort → **R**ange order for optimal performance

```javascript
// Query: 
// { ou_id: ObjectId, branch_id: ObjectId, status: 'active', created_at: { $gte: date }, price: { $lte: 100 } }
// SORT BY: created_at DESC

// ✅ CORRECT ESR order
{
  name: 'idx_ou_id_branch_id_status_created_at_price',
  key: {
    ou_id: 1,           // E - Equality
    branch_id: 1,       // E - Equality
    status: 1,          // E - Equality
    created_at: -1,     // S - Sort (DESC for this query)
    price: 1,           // R - Range
  },
}

// ❌ WRONG - not ESR order
{
  name: 'idx_price_created_at_status',
  key: {
    price: 1,
    created_at: -1,
    status: 1,
  },
}
```

### **Mandatory Composite Indexes**

Every collection must have compound index:
```javascript
// Base tenant isolation index
{
  name: 'idx_ou_id_branch_id_is_deleted',
  key: {
    ou_id: 1,
    branch_id: 1,
    is_deleted: 1,
  },
}

// Add other fields for common queries
{
  name: 'idx_ou_id_branch_id_is_deleted_status',
  key: {
    ou_id: 1,
    branch_id: 1,
    is_deleted: 1,
    status: 1,
  },
}
```

---

## 🔒 Tenant Isolation (CRITICAL)

Every query must include:
```javascript
{
  ou_id: ObjectId,        // Organization Unit ID
  branch_id: ObjectId,    // Branch ID
  is_deleted: false,      // Soft delete flag
  ...otherConditions,
}
```

---

## 📋 Mandatory Fields

Every document must have:

```javascript
{
  // Identity
  _id: ObjectId,

  // Tenant
  ou_id: ObjectId,
  branch_id: ObjectId,

  // Soft Delete (required)
  is_deleted: Boolean,
  deleted_by: String | null,
  deleted_date: Date | null,
  deleted_prog: String | null,

  // Audit Create (required)
  cr_by: String,
  cr_date: Date,
  cr_prog: String,

  // Audit Update (required)
  upd_by: String,
  upd_date: Date,
  upd_prog: String,

  // Business data
  ...otherFields,
}
```

### **Audit Field Descriptions**

```javascript
cr_by: 'username or service that created',      // 'john.doe' or 'batch-job'
cr_date: new Date('2026-05-15T10:30:00Z'),     // ISO 8601 UTC
cr_prog: '/api/v1/products' or 'cron-job',     // API endpoint or job name
upd_by: 'username or service that updated',
upd_date: new Date('2026-05-15T11:45:00Z'),
upd_prog: '/api/v1/products' or 'bulk-import',
is_deleted: false,
deleted_by: 'john.doe' or null,
deleted_date: new Date('2026-05-15T12:00:00Z') or null,
deleted_prog: '/api/v1/products' or null,
```

---

## 💰 Currency/Money Fields

```javascript
// ❌ WRONG - use number
{
  price: 1250.50,
}

// ✅ CORRECT - use Decimal128 in DB
{
  price: Decimal128('1250.50'),
}

// When sending to API - convert to String
{
  price: '1250.50',
}

// Conversion in code
import { Decimal128 } from 'mongodb';

// INSERT - String to Decimal128
const createPayload = {
  price: Decimal128.fromString(String(data.price)),
};

// SELECT - Decimal128 to String
function serializeDoc(doc) {
  return {
    price: doc.price instanceof Decimal128 ? doc.price.toString() : doc.price,
  };
}
```

---

## 🆔 ObjectId / ID Fields

```javascript
// ❌ WRONG - store as string
{
  _id: '507f1f77bcf86cd799439011',
  product_id: '507f1f77bcf86cd799439012',
}

// ✅ CORRECT - store as ObjectId
{
  _id: ObjectId('507f1f77bcf86cd799439011'),
  product_id: ObjectId('507f1f77bcf86cd799439012'),
}

// When sending to API - convert to String
{
  id: '507f1f77bcf86cd799439011',
  productId: '507f1f77bcf86cd799439012',
}

// Conversion in code
import { ObjectId } from 'mongodb';

// INSERT - accept String, convert to ObjectId
const payload = {
  product_id: new ObjectId(data.product_id),
};

// SELECT - ObjectId to String
const response = {
  id: doc._id.toString(),
  productId: doc.product_id.toString(),
};
```

---

## 📅 DateTime/Date Fields

```javascript
// ✅ CORRECT - store as UTC Date in DB
{
  created_at: new Date('2026-05-15T10:30:00Z'),
  updated_at: new Date('2026-05-15T11:45:00Z'),
}

// ✅ Send as ISO 8601 String to API
{
  createdAt: '2026-05-15T10:30:00Z',
  updatedAt: '2026-05-15T11:45:00Z',
}

// Never store timezone-specific times
// ❌ WRONG
{
  created_at: new Date('2026-05-15T17:30:00+07:00'),  // Include timezone
}

// Conversion in code
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc.js';

dayjs.extend(utc);

// INSERT - always convert to UTC
const now = dayjs.utc().toDate();
const payload = {
  created_at: now,
};

// SELECT - send as ISO 8601
const doc = await db.collection('products').findOne(_id);
const response = {
  createdAt: dayjs(doc.created_at).utc().format('YYYY-MM-DDTHH:mm:ssZ'),
};
```

---

## 🏢 Multi-Tenant Example

```javascript
// Collection: products
{
  _id: ObjectId,
  
  // Tenant fields (MUST HAVE)
  ou_id: ObjectId('507f1f77bcf86cd799439011'),  // Org Unit
  branch_id: ObjectId('507f1f77bcf86cd799439012'), // Branch
  is_deleted: false,
  
  // Business data
  product_code: 'PROD-001',
  product_name: 'Laptop',
  price: Decimal128('25000.00'),
  quantity: 50,
  status: 'active',
  
  // Audit fields
  cr_by: 'john.doe',
  cr_date: Date('2026-05-01T08:00:00Z'),
  cr_prog: '/api/v1/products',
  upd_by: 'jane.smith',
  upd_date: Date('2026-05-15T14:30:00Z'),
  upd_prog: '/api/v1/products',
  deleted_by: null,
  deleted_date: null,
  deleted_prog: null,
}

// Query - ALWAYS include tenant + is_deleted
db.collection('products').find({
  ou_id: ObjectId('507f1f77bcf86cd799439011'),
  branch_id: ObjectId('507f1f77bcf86cd799439012'),
  is_deleted: false,
  status: 'active',
})
```

---

## 🔍 Query Patterns

### **Find ONE (for detail)**
```javascript
// ✅ CORRECT
const doc = await db.collection('products').findOne({
  _id: ObjectId(id),
  ou_id: ObjectId(userContext.ou_id),
  branch_id: ObjectId(userContext.branch_id),
  is_deleted: false,
});

// ❌ WRONG - missing tenant
const doc = await db.collection('products').findOne({
  _id: ObjectId(id),
});

// ❌ WRONG - using find().toArray()[0]
const doc = await db.collection('products')
  .find({ _id: ObjectId(id) })
  .toArray()[0];
```

### **Find MANY (for list)**
```javascript
// ✅ CORRECT
const docs = await db.collection('products')
  .find({
    ou_id: ObjectId(userContext.ou_id),
    branch_id: ObjectId(userContext.branch_id),
    is_deleted: false,
    status: 'active',
  })
  .sort({ created_at: -1 })
  .skip((page - 1) * limit)
  .limit(limit)
  .toArray();

const total = await db.collection('products').countDocuments({
  ou_id: ObjectId(userContext.ou_id),
  branch_id: ObjectId(userContext.branch_id),
  is_deleted: false,
  status: 'active',
});
```

### **Aggregate (for complex queries)**
```javascript
// ✅ CORRECT - $match first
const results = await db.collection('products')
  .aggregate([
    {
      $match: {
        ou_id: ObjectId(userContext.ou_id),
        branch_id: ObjectId(userContext.branch_id),
        is_deleted: false,
        status: 'active',
      },
    },
    {
      $sort: { created_at: -1 },
    },
    {
      $group: {
        _id: '$category',
        total: { $sum: '$price' },
        count: { $sum: 1 },
      },
    },
  ])
  .toArray();
```

---

## 📊 Read Preference

```javascript
// Default - prefer primary
client.withReadPreference('primaryPreferred');

// Financial data - always use primary
db.collection('transactions')
  .find({...}, { readPreference: 'primary' });

// Reports - can use secondary
db.collection('products')
  .find({...}, { readPreference: 'secondary' });
```

---

## 🚀 Optimization Tips

1. **Use explain()** to verify index usage
```javascript
db.collection('products').find({ou_id, branch_id, status}).explain('executionStats');
```

2. **Monitor slow queries** via MongoDB logs

3. **Use Decimal128** for all monetary values

4. **Avoid null values** - use `is_deleted` instead

5. **Denormalize when needed** for performance (cache aggregations)

---

**Status:** Ready to Use ✅  
**Version:** 1.0  
**Last Updated:** 2026-05-15
