---
name: Backend Scaffold Skill
description: สร้าง Node.js + MongoDB Backend ตามมาตรฐาน 21 Rules อัตโนมัติ ด้วย 4 Agents ครบวงจร
version: "2.0"
author: Backend Architecture Team
tags:
  - backend
  - nodejs
  - mongodb
  - architecture
  - scaffold
  - code-review
  - refactoring
keywords:
  - 21 backend rules
  - 4-layer architecture
  - tenant isolation
  - optimistic locking
  - audit trail
  - scaffold project
  - add module
  - review code
  - refactor
---

# 🚀 Backend Scaffold Skill

**สร้าง Node.js + MongoDB Backend ตามมาตรฐาน 21 Rules อัตโนมัติ**

---

## 📋 วิธีใช้งาน

### **1. Scaffold Project ใหม่**
```bash
/scaffold-backend --name="user-service" --modules="users,auth,roles"
```

**ผลลัพธ์:**
- ✅ โครงสร้าง 4 layers (Route → Controller → Service → Repository)
- ✅ Boilerplate code สำหรับทุก module
- ✅ Database setup (MongoDB with Replica Set)
- ✅ Auth middleware (JWT + HTTPOnly Cookie)
- ✅ Error handling & logging
- ✅ Environment config
- ✅ Docker compose สำหรับ MongoDB
- ✅ Package.json พร้อม dependencies

---

### **2. Review Code ตามมาตรฐาน**
```bash
/review-backend --check-rules
```

**ตรวจสอบ:**
- ✅ Tenant isolation (ou_id + branch_id)
- ✅ Audit fields (cr_*, upd_*)
- ✅ Optimistic locking (upd_date)
- ✅ Soft delete (is_deleted)
- ✅ API response format
- ✅ Error handling pattern
- ✅ Transaction usage

---

## 📚 เนื้อหา Skill

### **Standards (เอกสารอ้างอิง)**
| ไฟล์ | เนื้อหา |
|------|--------|
| **backend-rules-21.md** | 21 Rules ทั้งหมด + Quick Reference |
| **architecture.md** | 4-layer architecture + patterns |
| **db-standards.md** | MongoDB schema + index naming |
| **api-response-format.md** | Response wrapper + error codes |
| **naming-conventions.md** | camelCase, snake_case, kebab-case |

### **Templates (Boilerplate)**
| ไฟล์ | ใช้สำหรับ |
|------|---------|
| **package.json.template** | Dependencies list |
| **.env.example** | Environment variables |
| **database-template.js** | MongoDB connection + utilities |
| **middleware-template.js** | Auth, validation, error handling |
| **route-template.js** | Route definitions pattern |
| **controller-template.js** | Controller boilerplate |
| **service-template.js** | Business logic pattern |
| **repository-template.js** | Database access pattern |

### **Agents (AI Prompts) - 4 Complete Agents**
| Agent | จุดประสงค์ | ใช้สำหรับ |
|--------|----------|---------|
| **scaffold-node-backend.md** | สร้าง project ใหม่จากศูนย์ | สร้าง backend project ทั้งหมด พร้อม modules, db setup, docker-compose |
| **add-module.md** | เพิ่ม module ใหม่เข้าโปรเจค | เพิ่ม CRUD resource ใหม่ (products, users, orders) ให้เสร็จสมบูรณ์ |
| **review-backend-code.md** | ตรวจสอบ code ตามมาตรฐาน | Review code กับ 21 rules, identify violations + fix suggestions |
| **refactor-code.md** | ปรับปรุง code ให้ดีขึ้น | Refactoring guide: 8 scenarios, performance tips, best practices |

---

## 🤖 Agent ใช้ได้ตลอด Development Lifecycle

### **1️⃣ Scaffold Project (สร้างใหม่)**
```bash
/scaffold-backend --name="ecommerce-api" --modules="products,orders,payments"
```
**ผลลัพธ์:** Project folder พร้อมทั้งหมด (config, middleware, modules, db setup)

### **2️⃣ Add Module (เพิ่ม CRUD)**
```
เพิ่มเม็ดเข้า module ใหม่เช่น "suppliers", "inventory", "reports"
- สร้าง 5 files: validator, repository, service, controller, route
- Verify 21 rules ทั้งหมด
- ให้ database schema + indexes
- Integration instructions
```

### **3️⃣ Review Code (ตรวจสอบมาตรฐาน)**
```
ส่ง code ให้ agent ตรวจสอบกับ 21 rules
- ✅ Tenant isolation
- ✅ Optimistic locking
- ✅ Audit trail
- ✅ Error handling
- ✅ Response format
```

### **4️⃣ Refactor Code (ปรับปรุง)**
```
ส่ง code ที่ต้องปรับปรุง (slow, duplicate, N+1 queries)
- ✅ Optimize parallel queries
- ✅ Extract helper functions (DRY)
- ✅ Add missing indexes (10-100x faster)
- ✅ 8 refactoring patterns
```

---

## ✨ Features

### **Automatic Enforcement**
- ✅ 21 Backend rules บังคับใช้
- ✅ Naming conventions อัตโนมัติ
- ✅ Error handling ครบถ้วน
- ✅ Audit trail logging
- ✅ Tenant isolation
- ✅ Optimistic locking

### **Complete Boilerplate**
- ✅ Express app setup
- ✅ MongoDB connection
- ✅ Authentication (JWT + HTTPOnly)
- ✅ Rate limiting
- ✅ Validation (Joi)
- ✅ Logger (Pino)
- ✅ CRUD templates

### **Production Ready**
- ✅ Docker compose included
- ✅ Environment validation
- ✅ Error handling middleware
- ✅ Request ID tracking
- ✅ Security headers

---

## 📖 วิธีใช้งาน Step by Step

### **ขั้นตอนที่ 1️⃣: สร้าง Project ใหม่**

**ต้องการ:** สร้าง backend project ใหม่ พร้อมโปรเจคที่มีมาตรฐาน

**วิธีใช้:**
```
ส่งให้ Agent: /scaffold-backend --name="my-api" --modules="users,products"
```

**ระบุ:**
- `--name` = ชื่อโปรเจค (เช่น "ecommerce-api", "user-service")
- `--modules` = resources ที่ต้องการ (เช่น "products,orders,payments")

**ผลลัพธ์ที่ได้:**
✅ โฟลเดอร์โปรเจคพร้อมใช้  
✅ ทั้ง config, middleware, modules, docker-compose  
✅ ติดตั้ง npm dependencies  
✅ มาตรฐาน 21 rules บังคับใช้ตั้งแต่ต้น  

**หลังจากนั้น:**
```bash
cd my-api
npm install
npm run dev
# เข้าไปที่ http://localhost:3000/health เพื่อตรวจสอบ
```

---

### **ขั้นตอนที่ 2️⃣: เพิ่ม Module ใหม่ (CRUD Resource)**

**ต้องการ:** เพิ่ม feature ใหม่เช่น "suppliers", "inventory", "categories"

**วิธีใช้:**
```
ส่งให้ Agent: /add-module
```

**ระบุ:**
1. **ชื่อ module** - "products", "users", "orders" เป็นต้น
2. **Fields** - ข้อมูลที่เก็บ เช่น "name, price, quantity, description"
3. **Relations** - เชื่อมโยงกับ module อื่นไหม เช่น "products belong to categories"
4. **Business Logic** - กฎพิเศษ เช่น "price ต้อง > 0", "code ต้อง unique"

**ผลลัพธ์ที่ได้:**
✅ 5 ไฟล์สำเร็จ:
- `<module>.validator.js` - ตรวจสอบข้อมูล
- `<module>.repository.js` - ติดต่อ database
- `<module>.service.js` - business logic
- `<module>.controller.js` - handle request
- `<module>.route.js` - define endpoints

✅ Database schema + indexes ready  
✅ ตรวจสอบ 21 rules ทั้งหมดแล้ว  
✅ Ready to integrate กับ app.js  

**ขั้นตอนการ integrate:**
```javascript
// ใน app.js
import suppliersRoutes from './modules/suppliers/suppliers.route.js';
app.use('/api/v1/suppliers', suppliersRoutes);
```

---

### **ขั้นตอนที่ 3️⃣: ตรวจสอบ Code ตาม Standards**

**ต้องการ:** ตรวจสอบ code ตรงตามมาตรฐาน ก่อน commit

**วิธีใช้:**
```
1. Copy code ที่เขียนมา
2. ส่งให้ Agent: /review-backend-code
3. ระบุ: "โปรดตรวจสอบ code นี้ตาม 21 rules"
```

**ตรวจสอบอะไร:**
✅ Tenant isolation (ou_id + branch_id ทุก query)  
✅ Optimistic locking (check upd_date)  
✅ Audit fields (cr_*, upd_*)  
✅ Error handling (ส่ง error ไป next(err))  
✅ Response format (requestId มีครบ)  
✅ Logging (ไม่มี console.log)  
✅ และ 15 rules อื่น ๆ  

**ผลลัพธ์:**
- ❌ Violations found - มีข้อ violated
- 💡 Fix suggestions - แนะนำวิธีแก้
- ✅ Fixed examples - ตัวอย่าง code ที่ถูก

---

### **ขั้นตอนที่ 4️⃣: ปรับปรุง Performance**

**ต้องการ:** Code ช้า, duplicate, หรือ N+1 queries

**วิธีใช้:**
```
1. Copy code ที่ต้องปรับปรุง
2. ส่งให้ Agent: /refactor-code
3. ระบุ: "โปรดปรับปรุง code นี้ให้เร็วขึ้น"
```

**แนะนำ 8 Refactoring Patterns:**

| ปัญหา | การแก้ไข | ผลลัพธ์ |
|-------|---------|--------|
| Waterfall API calls | ใช้ Promise.all | 3x faster ⚡ |
| Duplicate code | Extract helper functions | DRY code 📦 |
| Missing indexes | Add ESR indexes | 10-100x faster 🔥 |
| Fat controller | Proper layer separation | Testable code ✅ |
| Bad error handling | Comprehensive errors | Debuggable 🐛 |
| console.log | Structured logging | Searchable logs 🔍 |
| N+1 queries | Batch queries | 2 queries vs N+1 💨 |
| No audit trail | Add transaction logging | Traceable changes 📋 |

**ผลลัพธ์:**
- ✨ Refactored code - code ที่ปรับปรุงแล้ว
- 📊 Before/After - เปรียบเทียบ
- ⏱️ Performance gains - ได้ประโยชน์เท่าไหร่

---

## 🎯 ตัวอย่างการใช้งาน Full Scenario

### **สร้าง project ใหม่**
```bash
/scaffold-backend --name="ecommerce-api" --modules="products,orders,customers,payments"
```

**จะได้ folder structure:**
```
ecommerce-api/
├── src/
│   ├── config/
│   │   └── database.js
│   ├── modules/
│   │   ├── products/
│   │   │   ├── products.route.js
│   │   │   ├── products.controller.js
│   │   │   ├── products.service.js
│   │   │   ├── products.repository.js
│   │   │   └── products.validator.js
│   │   ├── orders/
│   │   ├── customers/
│   │   └── payments/
│   ├── middleware/
│   │   ├── authenticate.js
│   │   ├── validate.js
│   │   ├── rateLimit.js
│   │   ├── requestId.js
│   │   └── errorHandler.js
│   ├── utils/
│   │   ├── app-error.js
│   │   ├── format.js
│   │   └── logger.js
│   ├── app.js
│   └── server.js
├── package.json
├── .env.example
├── docker-compose.yml
└── STANDARDS.md (reference)
```

**ทั้งหมดตรงตาม 21 rules!** ✅

---

## ⚠️ Best Practices (สิ่งที่ต้องจำ)

### **✅ ต้องทำ (DO's)**
- ✅ **ทุก query ต้องมี `tenantFilter()`** - ตรวจสอบ `ou_id` + `branch_id`
- ✅ **UPDATE/DELETE ต้องเช็ค `upd_date`** - Optimistic locking
- ✅ **ใช้ transactions** - Create/Update/Delete + Log = 1 transaction
- ✅ **Soft delete เสมอ** - ใช้ `is_deleted: true`, ไม่ลบจริง
- ✅ **ส่งข้อมูลทาง `next(err)`** - ไม่ใช่ `res.json()` ใน catch
- ✅ **ใช้ logger.info/error** - ไม่มี console.log ใน production
- ✅ **API response มี `requestId`** - track every request
- ✅ **Money เป็น String** - DB = Decimal128, API = String
- ✅ **DateTime เป็น ISO 8601** - UTC format เสมอ

### **❌ ต้องหลีกเลี่ยง (DON'Ts)**
- ❌ **Query โดยไม่มี tenant filter** - จะมี data leak
- ❌ **Update โดยไม่เช็ค version** - Concurrent update collision
- ❌ **Hardcode secrets** - `DATABASE_URL`, `JWT_SECRET` ต้องใน .env
- ❌ **ลบข้อมูลจริง** - ใช้ soft delete แทน
- ❌ **Mongoose ODM** - ใช้ mongodb native driver
- ❌ **require() statements** - ใช้ import/export เท่านั้น
- ❌ **console.log ใน production** - ใช้ logger เท่านั้น
- ❌ **Money as number** - จะสูญเสีย precision (0.1 + 0.2 != 0.3)
- ❌ **Waterfall API calls** - ใช้ Promise.all แทน

---

## 🆘 Troubleshooting

### **"Module not found" หลังจาก add-module**
**แก้ไข:** ต้อง import route ใน `app.js` และ restart server

### **"Tenant isolation error"**
**สาเหตุ:** Query ลืม `tenantFilter()` ⟹ check rule #1

### **"Decimal128 sent to API"**
**สาเหตุ:** ลืม convert to String ⟹ ใช้ `serializeDoc()`

### **"Update conflicts"**
**สาเหตุ:** ไม่เช็ค `upd_date` ⟹ add optimistic locking check

### **ต้องการ help**
```
1. อ่าน: standards/backend-rules-21.md
2. เปรียบเทียบกับ: templates/ (boilerplate)
3. ส่ง code ให้ /review-backend-code agent
```

---

## 🔍 Standards Quick Reference

### **21 Rules Summary**

| # | กฎ | ตัวอย่าง |
|---|---|---------|
| 1 | Tenant Isolation | `{ou_id, branch_id, is_deleted}` ต้องมีทุก query |
| 2 | Optimistic Locking | Check `upd_date` ก่อน update/delete |
| 3 | Audit Fields | `cr_date, cr_by, cr_prog, upd_date, upd_by, upd_prog` |
| 4 | No Mongoose | ใช้ `mongodb` native driver เท่านั้น |
| 5 | No Hardcode | ENV vars ทั้งหมด |
| 6 | Real HTTP Status | 200 success, 400 bad request, 401 unauthorized, etc. |
| 7 | ISO 8601 DateTime | ส่ง UTC string เสมอ |
| 8 | Money as String | DB=Decimal128, API=String |
| 9 | findOne for Detail | ห้าม find().toArray()[0] |
| 10 | ESR Index Order | Equality → Sort → Range |
| 11 | Global Error Handler | ทุก error ต้อง next(err) |
| 12 | Request ID | ทุก request มี requestId |
| 13 | Auth Middleware | JWT decode ใน middleware เท่านั้น |
| 14 | Soft Delete | is_deleted: false ทั้งหมด |
| 15 | Transaction | Create/Update/Delete + Log = 1 transaction |
| 16 | CRUD Pattern | Route → Controller → Service → Repository |
| 17 | Validate Middleware | ใช้ validate(schema) เสมอ |
| 18 | Logger (Pino) | ห้าม console.log |
| 19 | Middleware Order | requestId → body → proxy → rateLimit → routes → 404 → errorHandler |
| 20 | Decimal128 | แปลง String ก่อนส่ง response |
| 21 | ESM Only | import/export เท่านั้น |

---

## 📖 ใช้ร่วมกับ

- **Cursor IDE** - เรียก `/scaffold-backend` ในการสร้าง project
- **Claude Code** - ใช้เป็นตัวช่วยในการ review code
- **agent.md** - Reference document สำหรับ development

---

## 🎓 Development Workflow

### **Day 1: Project Setup**
1. `/scaffold-backend --name="my-api" --modules="users,products"`
2. `npm install && npm run dev`
3. Test: `curl http://localhost:3000/health`

### **Day 2-N: Feature Development**
1. **Need new CRUD?** → Use `/add-module` agent
   - Specify: module name, fields, relations, business logic
   - Get: complete 5 files + db schema + integration steps
   
2. **Write code** → Follow templates + 21 rules

3. **Before commit** → Use `/review-backend` agent
   - Paste code to review
   - Check: 21 rules violations
   - Get: detailed fix suggestions

4. **Optimization** → Use `/refactor-code` agent
   - Identify slow code (N+1, waterfall calls)
   - Get: refactored version + performance gains

### **Key Milestones**
- ✅ Project setup (all standards baked in)
- ✅ Each module follows same pattern
- ✅ Code reviews automated
- ✅ Performance optimization guided

---

## ✅ What You Get

- ✅ 21 Backend Rules อ้างอิง
- ✅ 4-Layer Architecture Template
- ✅ 8 Boilerplate Files
-