# 🚀 Backend Scaffold Skill

**Node.js + MongoDB Backend Standard Templates & Documentation**

สร้าง backend project ใหม่ที่มีมาตรฐานเสมอ โดยปฏิบัติตาม 21 Backend Rules

---

## 📁 ไฟล์ที่อยู่ใน Skill นี้

### **Standards/** (เอกสารอ้างอิง)
| ไฟล์ | เนื้อหา |
|------|--------|
| **backend-rules-21.md** | 21 rules ทั้งหมด + code examples |
| **architecture.md** | 4-layer architecture pattern |
| **db-standards.md** | MongoDB schema + indexing |
| **api-response-format.md** | Response wrapper + error codes |
| **naming-conventions.md** | Naming rules (camelCase, snake_case, etc.) |

### **Templates/** (Boilerplate)
| ไฟล์ | ใช้สำหรับ |
|------|---------|
| **package.json.template** | Dependencies list |
| **.env.example** | Environment variables |
| **database-template.js** | MongoDB connection |
| **middleware-template.js** | Auth, validation, error handling |
| **route-template.js** | Route pattern |
| **controller-template.js** | Controller boilerplate |
| **service-template.js** | Service pattern |
| **repository-template.js** | Repository pattern |
| **app-error.js** | Custom error class |
| **logger.js** | Pino logger setup |
| **project-structure.txt** | Folder structure reference |

### **Agents/** (AI Prompts)
| ไฟล์ | จุดประสงค์ |
|------|----------|
| **scaffold-node-backend.md** | Generate new project |

---

## 🎯 วิธีใช้งาน

### **1. สร้าง Project ใหม่**

```bash
/scaffold-backend --name="my-api" --modules="products,users,orders"
```

**ผลลัพธ์:**
- Complete project structure ✅
- All boilerplate files ✅
- Database setup ✅
- Docker Compose ✅
- Environment config ✅

### **2. เพิ่ม Module ใหม่**

Copy template files จาก `templates/` และ:
1. Rename `<module>` → your module name
2. Update database collection names
3. Update validator schemas
4. Import route ใน app.js

### **3. Reference Standards**

ระหว่าง development อ่าน:
- `backend-rules-21.md` - ตรวจสอบกฎ
- `architecture.md` - ทำความเข้าใจ 4 layers
- `api-response-format.md` - API response format
- `naming-conventions.md` - ชื่อตัวแปร/ฟังก์ชัน/เฟิลด์

---

## 📋 21 Backend Rules (Quick Reference)

```
1. Tenant Isolation    - ou_id + branch_id ทุก query
2. Optimistic Locking  - check upd_date ทุก update
3. Audit Fields        - cr_* + upd_* ทั้งหมด
4. No Mongoose         - native mongodb driver
5. No Hardcode         - ENV vars ทั้งหมด
6. Real HTTP Status    - 200/400/401/403/404/500
7. ISO 8601 DateTime   - UTC ทั้งหมด
8. Money as String     - DB=Decimal128, API=String
9. findOne for Detail  - ห้าม find().toArray()[0]
10. ESR Index Order    - Equality → Sort → Range
11. Global Error       - next(err) เสมอ
12. Request ID         - ทุก request
13. Auth Middleware    - JWT decode เท่านั้น
14. Soft Delete        - is_deleted flag
15. Transaction        - CREATE/UPDATE/DELETE + LOG
16. CRUD Pattern       - Route → Controller → Service → Repository
17. Validate Middleware - validate(schema) ทั้งหมด
18. Logger (Pino)      - ห้าม console.log
19. Middleware Order   - requestId → body → proxy → rateLimit → routes → 404 → errorHandler
20. Decimal128         - แปลง String ก่อนส่ง
21. ESM Only           - import/export เท่านั้น
```

---

## 🏗️ Architecture

### **4-Layer Pattern**

```
HTTP Request
    ↓
[ROUTE] ← Validation + Middleware
    ↓
[CONTROLLER] ← Orchestration + HTTP Response
    ↓
[SERVICE] ← Business Logic + Error Handling
    ↓
[REPOSITORY] ← Database Access Only
    ↓
Database
```

### **File Structure per Module**

```
modules/products/
├── products.route.js       ← Endpoints
├── products.controller.js  ← HTTP orchestration
├── products.service.js     ← Business logic
├── products.repository.js  ← DB access
└── products.validator.js   ← Input validation
```

---

## 💻 Quick Start

### **Step 1: Generate Project**
```bash
/scaffold-backend --name="ecommerce-api" --modules="products,users,orders"
```

### **Step 2: Install Dependencies**
```bash
cd ecommerce-api
npm install
```

### **Step 3: Start MongoDB**
```bash
docker-compose up -d
```

### **Step 4: Setup Environment**
```bash
cp .env.example .env
# Edit .env with your values
```

### **Step 5: Run Server**
```bash
npm run dev
```

### **Step 6: Check Health**
```bash
curl http://localhost:3000/health
```

---

## 📚 Example: Creating Products Module

### **1. Create Folder**
```
src/modules/products/
```

### **2. Create Files (from templates)**
```javascript
// products.route.js
import express from 'express';
import { authenticate, validate } from '../middleware/index.js';
import * as productController from './products.controller.js';
import { createProductSchema } from './products.validator.js';

const router = express.Router();

router.get('/', authenticate, productController.listProducts);
router.post('/', authenticate, validate(createProductSchema), productController.createProduct);

export default router;
```

### **3. Import in app.js**
```javascript
import productRoutes from './modules/products/products.route.js';

app.use('/api/v1/products', productRoutes);
```

### **4. Create Database Index**
```javascript
await createCollectionIndexes('products', [
  {
    name: 'idx_ou_id_branch_id_is_deleted',
    key: { ou_id: 1, branch_id: 1, is_deleted: 1 }
  }
]);
```

That's it! ✅

---

## 🔍 Standards Checklist

When writing code, verify:
- [ ] Variables are `camelCase`
- [ ] Database fields are `snake_case`
- [ ] API response fields are `camelCase`
- [ ] No `console.log()` - use `logger.*`
- [ ] No `require()` - use `import`
- [ ] All DB queries have `tenantFilter()`
- [ ] All UPDATE/DELETE check `upd_date`
- [ ] All responses have `requestId`
- [ ] Errors passed to `next(err)` - not `res.json()`
- [ ] All 21 rules followed

---

## 📖 Learning Path

1. **First Time:**
   - Read: `backend-rules-21.md`
   - Read: `architecture.md`
   
2. **Creating New Module:**
   - Reference: `project-structure.txt`
   - Copy: template files
   - Check: `naming-conventions.md`

3. **Debugging:**
   - Check: `api-response-format.md`
   - Check: `db-standards.md`
   - Run: code against 21 rules

4. **Deep Dive:**
   - All files in `standards/`
   - All files in `templates/`

---

## ✅ What Makes This Standard

✅ **Consistency** - Same pattern every time  
✅ **Security** - Tenant isolation enforced  
✅ **Reliability** - Audit trail + optimistic locking  
✅ **Scalability** - Clean architecture  
✅ **Maintainability** - Clear responsibilities  
✅ **Quality** - Error handling complete  

---

## 🎓 Common Questions

**Q: How do I add a new module?**
A: Copy template files from `templates/`, rename `<module>` to your module name, follow 4-layer pattern.

**Q: What if I need custom validation?**
A: Add custom Joi schema in `<module>.validator.js`, import in route.

**Q: How do I handle transactions?**
A: Repository layer handles this automatically. See `repository-template.js`.

**Q: Can I use Mongoose?**
A: No - Rule #4 says native mongodb driver only. This ensures explicit control.

**Q: What about TypeScript?**
A: Code is TypeScript-ready. Add `.ts` extension and tsconfig.json when needed.

---

## 📞 Support

Stuck? Check:
1. `backend-rules-21.md` - Are you following all rules?
2. `architecture.md` - Is your code in the right layer?
3. `api-response-format.md` - Is your response format correct?
4. Template files - Copy-paste the pattern

---

**Status:** ✅ Ready to Use  
**Version:** 1.0  
**Last Updated:** 2026-05-15  
**Backend Stack:** Node.js 24.11 LTS + MongoDB 8.0+ + Express
